<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReportCtrl extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
   
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];

 switch ($met)  
 {  
   case "MetaData":
    $this->MetaData($parametros);
   break;

 }
 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
   //   $this->Edit(); 
    break;
    case 'POST': 
     // $this->Add();
    break;
    case 'GET': 
      $this->FnGet($parametros);
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
    //  $this->Delete($parametros); 
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }
  
 private function FnGet($parametros){

    header('Content-type: application/json; charset=utf-8');
    echo json_encode("Hola"); 

 }
  
private function MetaData(){
  //$Reportes =array();
  //$Reportes = $this->ReportModels->MetaData();
  header('Content-type: application/json; charset=utf-8');
  $obj = new stdClass();
  $obj->Inventario = "ReporWarehouse2";
  $obj->MovimientoAlmacen = "ReporWareDetalle2";
  $obj->ReportVentas = "ReporVentas";
  
  echo json_encode($obj); 
}

    protected function middleware()
    {
      return ['Sesion','Permisos'];
    }

	
}