<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CodigoAuxCtrl extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
      $this->load->library('Pdf');
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];

 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
    $this->CambiarCodigoAux();
    break;
    case 'POST': 
      
    break;
    case 'GET': 
     
      echo json_encode($this->WarehouseModels->generarCodigo());
 break;
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
      
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }
 private function CambiarCodigoAux(){
    $Datos = $this->input->raw_input_stream;
    if(is_string($Datos) ===true){
      $Datos =  json_decode($Datos, true);
    }
    $Res = "Error codigo ya asignmado";
   if( isset($Datos["ID"]) && isset($Datos["CodigoAux"]) && isset($Datos["Codigo"])){
    $Res= $this->CodigoAuxModels->Edit($Datos);
   } 
   echo json_encode($Res);
 }

    protected function middleware()
    {
      return ['Sesion'];
    }

	
}