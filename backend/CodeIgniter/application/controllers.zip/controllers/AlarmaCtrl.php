<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class AlarmaCtrl extends MY_Controller { 
function __construct() {
  
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header('content-type: application/json; charset=utf-8');
  $method = $_SERVER['REQUEST_METHOD'];
  if($method == "OPTIONS") {
      die();
  }
parent::__construct(); 
}


public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];
 if($met ==="Alarma"){


  $this->AlarmasModels->Alarma();
 }
 if($met ==="Alarma2"){
  
  Async('/CodeIgniter/Alarma');
  sleep(60);
  
 }

 
 echo json_encode('{"Respuesta": "ok"}');
 }

protected function middleware()
{
  return ['Sesion'];
 // return ['Sesion','Permisos'];
}
}
/* end CertificadoBalsaCtrl.php file for CodeIgniter TCPDF Integration */
?>