<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ShipCtrl extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];

 switch ($met)  
 { case 'Buscar1':
     $this->Buscar1($parametros); 
     break;
   case 'Buscar2': 
     $this->Buscar2($parametros);   
   break;
   case 'Buscar3': 
     $this->Buscar3($parametros); 
   break; 
   case 'Buscar4': 
    $this->Buscar4($parametros);
   break; 
   case 'Buscar5': 
    $this->Buscar5($parametros);
   break; 
   case "MetaData":
    $this->MetaData($parametros);
   break;

 }
 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
      $this->Edit(); 
    break;
    case 'POST': 
      $this->Add();
    break;
    case 'GET': 
      $this->Search($parametros);
 break;
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
      $this->Delete($parametros); 
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }
private function Add(){
  $Datos = count($_POST) ===0 ? $this->input->raw_input_stream :  $this->input->post();
  if(is_string($Datos) ===true){
    $Datos =  json_decode($Datos, true);
  }

    $Shipes= $this->ShipModels->Add($Datos);

  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes);
}
     
private function Edit(){
  $Datos = $this->input->raw_input_stream;
  if(is_string($Datos) ===true){
    $Datos =  json_decode($Datos, true);
  }
  $Shipes= $this->ShipModels->Edit($Datos);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes);
    
}

private function Delete($ID ){
  $Shipes= $this->ShipModels->Delete($ID[0]);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes);
}

// aqui viene los metodos de buscar



private function Search($Arr =array() ){
  $Shipes =array();
  switch (count($Arr)) 
  { case 0:
    $Shipes= $this->ShipModels->getShip();
    break;
    case 1: 
      $Shipes = $this->ShipModels->getShip($Arr[0]);
    break;
    case 2: 
      $Shipes = $this->ShipModels->getShipLimite($Arr[0],$Arr[1]);
    break; 
    case 4: 
      $Shipes = $this->ShipModels->getShipLimiteOrden($Arr[0],$Arr[1],$Arr[2],$Arr[3]);
    break; 
    case 5: 
      $Shipes = $this->ShipModels->getShipLimiteOrdenColumnas($Arr[0],$Arr[1],$Arr[2],$Arr[3],urldecode($Arr[4]));
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 
}

private function Buscar1 ($Arr = array()){
  $Shipes =array();
  switch (count($Arr)) 
  {
    case 1: 
      $Shipes = $this->ShipModels->getShipFiltro(urldecode($Arr[0]));
    break;
    case 3: 
      $Shipes = $this->ShipModels->getShipFiltroLimite(urldecode($Arr[0]),$Arr[1],$Arr[2]);
    break; 
    case 5: 
      $Shipes = $this->ShipModels->getShipFiltroLimiteOrden(urldecode($Arr[0]),$Arr[1],$Arr[2],$Arr[3],$Arr[4]);
   break; 
   case 6: 
    $Shipes = $this->ShipModels->getShipFiltroLimiteOrdenColumnas(urldecode($Arr[0]),$Arr[1],$Arr[2],$Arr[3],$Arr[4],urldecode($Arr[5]));
    break; 
   default: 
   echo json_encode( $Arr );
   break; 
  }
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 
  
}
private function Buscar2 ($Arr =array()){
  $Shipes =array();
  $Shipes = $this->ShipModels->getShipFiltroColumnas(urldecode($Arr[0]),urldecode($Arr[1]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 
}

private function Buscar3 ($Arr =array()){
  $Shipes =array();
    $Shipes= $this->ShipModels->  getShipIdColum($Arr[0],urldecode($Arr[1]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 
}
private function Buscar4 ($Arr = array()){
  $Shipes =array();
    $Shipes= $this->ShipModels->getShipLimiteColum($Arr[0],$Arr[1],urldecode($Arr[2]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 
}
private function Buscar5 ($Arr =  array()){
  $Shipes =array();
  $Shipes = $this->ShipModels->getShipFiltroLimitesColumnas(urldecode($Arr[0]),$Arr[1],$Arr[2],urldecode($Arr[3]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 

}


private function MetaData(){
  $Shipes =array();
  $Shipes = $this->ShipModels->MetaData();
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Shipes); 
}

    protected function middleware()
    {
      return ['Sesion','Permisos'];
    }

	
}