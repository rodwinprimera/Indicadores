<?php class BuscarCertificadoBalsasCtrl extends MY_Controller { 
    
    function __construct() {
     
   
    parent::__construct(); 
    // add library of Pdf 
    $this->load->library('Pdf');
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    }
    
    
    public function _remap($met,$parametros = array()){
    
      $method = $_SERVER['REQUEST_METHOD'];
    
    
     if($met ==="index"){
    
      switch ($method)  
      { case 'PUT':
         // $this->Edit(); 
        break;
        case 'POST': 
          //$this->Add();
        break;
        case 'GET': 
          $this->GestionCertificado($parametros);
        case 'HEAD': 
          // echo json_encode( $method );
        break; 
        case 'DELETE': 
         // $this->Delete($parametros); 
        break; 
        case 'OPTIONS': 
         // echo json_encode( $method );
       break; 
       default: 
       echo json_encode( "Error" );
       break; 
      }
    }
    
    
     }
    
    
    
 

    
    public function GestionCertificado($parametros)
    {
      
      $Dir = Raiz();
      if(count($parametros) ===1){ 
        $Token = FALSE;
        $Header =  $this->input->request_headers();
        if(isset($Header['Authorization'])){
            $Authorization= $Header['Authorization'];
            if(  $Authorization !=""){
                $Authorization =str_replace('Bearer ','', $Authorization);
                $Token = ValidarToken($Authorization);
            }
        }
        if ( $Token === FALSE ){
          $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
        
         
          $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
          $Token  =$DatosGET!=''?$DatosGET: $Token ;
          
         }
         if(isset($this->session)){
          $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
       }else{
          $ID =   $Token== FALSE ? null :  $Token ;
       }
       
        if ($ID==null){
          $Balsa = $this->RaftModels->getRaftFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0].'|StatusCertificado^Activo',1,0,0,"1",'s0|12|13');
          if(count($Balsa)>0){
        }else{
         
            echo "Balsa Sin Certificado";
            return;
        } 
         //return print_r (  $Balsa);
     
          $Minuteses = $this->MinutesFModels->getMinutesFFiltroLimite("s16^".$parametros[0],1,0);
          $Minuteses = $this->MinutesFModels->getMinutesF( $Minuteses[0]->ID);
        
          // buscamos la informacion que llevara el certificado
        
 $Orden = $this->ReporDetalleOrdenModels->getReporDetalleOrden2($Minuteses->Detalle);

 $Minuteses = $this->MinutesFModels->getMinutesF($Orden[0]->Insumos);

 $Hola =json_decode((utf8_encode(json_encode($Orden[0]))),true);
 $CodigoDetalle= $Hola[utf8_encode('Código')];
 $CodigoOrden= $Hola[utf8_encode('Orden')];
 
  $DatosArmador  = $this->ClientModels->getClient($Orden[0]->Armador);
   $Embarcacion = $Orden[0]->Embarcacion;
   $Armador =  $Orden[0]->Armador.' '. $Orden[0]->Apellido;
   $Capacidad = $Orden[0]->Capacidad;
   $Serial = $Orden[0]->Balsa;
   $CerAnt = $Minuteses->CertificadoA;
   $Marca = $Orden[0]->Marca;
   $Email =  $Orden[0]->Email;
   $FechaI = $Minuteses->FechaI;
   $Fecha = $Minuteses->Fecha;
   $FechaV = $Minuteses->FechaV;
   $Pack = $Minuteses->Pack;
   $Year =  date("Y",strtotime($Minuteses->FechaI));
    $ArrayORden = array('Serial','Tara','CO2','N2','Peso','ULTIMOPH' );
   $BodyCilindros=  $this->BodyTabla($Minuteses->CILINDROS, $ArrayORden); 
   $ArrayProduc = array('Nombre','Cantidad','Vence','Observacion');
   $Observacion = $Minuteses->observacion;
   $Arreglo = [];
   $ListaProd =  array('BENGALAS DE MANO','COHETES PARACAIDAS','BOMBA DE HUMO','RACIÓN DE ALIMENTO','RACIÓN DE AGUA','BOTIQUÍN','PASTILLAS ANTIMAREO','BATERIA SALVAVIDA','PILAS LINTERNA','KIT DE REPARACIONES');
   $ArrayORden = array('Serial','Tara','CO2','N2','Peso','ULTIMOPH' );
   $BodyCilindros=  $this->BodyTabla($Minuteses->CILINDROS, $ArrayORden); 
   $PT = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^PT|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');
 
 
   $Predeterminado = new stdClass();
 $Predeterminado->Status2="";
 $Predeterminado->Fecha="";
 if(count($PT)>0){
  $PT = $PT[0];
 }else{
  $PT = $Predeterminado;
 }

 $IG = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^IG|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');

 $IG = count($IG) > 0 ? $IG[0] : $Predeterminado ;

 $CP = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^CP|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');
 $CP = count($CP) > 0 ? $CP[0] : $Predeterminado ;
 $PAN = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^PAN|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');
 $PAN = count($PAN) > 0 ? $PAN[0] : $Predeterminado ;
 $Acta = $this->RaftModels->getRaft($Orden[0]->IDBALSA);
 $ArrayProduc = array('Nombre','Cantidad','Vence','Observacion');
 $Arreglo2 = [];
 $ActaA = "";
 $ActaA = $this->MinutesModels->getMinutes($Orden[0]->Acta);

 if(is_null($ActaA)){
   $ActaA = $this->MinutesFModels->getMinutesF($Orden[0]->Acta); 
 }
  foreach ( $ActaA->ELEMENTOS as $val){
      if($val->Cantidad >= 0){
        $AuxPo = false;
        foreach ( $Arreglo as $val2){
         if($val2->Producto === $val->Producto ){
           if( $val->Cantidad - $val2->Cantidad > 0){
            $val2->Cantidad  = ($val->Cantidad - $val2->Cantidad) + $val2->Cantidad ;
           }
          if($this->BuscarDentro($ListaProd,$val2->Nombre) === true){
            array_push($Arreglo2,$val2 );
          }
          
          $AuxPo = true; 
         }
       
        }
        if( $AuxPo === false){
          if($this->BuscarDentro($ListaProd,$val->Nombre) === true){
            array_push($Arreglo2,$val );
          }
          
        }
        
       
      }
   
       
  }
 $BodyProduc =  $this->BodyTabla($Arreglo2, $ArrayProduc); 
 $Acta= $Acta[0];
 $Valvula = $this->ValveModels->getValveFiltro('sBalsa^'.$Orden[0]->CodigoBalsa);
 $Valvula=  $Valvula[0];

          $data = array(
            'Embarcacion'=> $Embarcacion,
            'Armador'=> $Armador,
            'Serial'=>   $Serial ,
            'Marca'=> $Marca,
            'Fecha'=>  $Fecha ,
            'Pack'=>    $Pack,
            'CerAnt'=>  $CerAnt,
            'FechaI' =>  $FechaI,
            'FechaV'=>   $FechaV,
            'Capacidad'=>   $Capacidad,
            'BodyTablaCilindro'=> $BodyCilindros,
            'PT'=>$PT->Status2,
            'IG'=>$IG->Status2,
            'CP'=>$CP->Status2,
            'PAN'=>$PAN->Status2,
            'PTF'=>$PT->Fecha,
            'IGF'=>$IG->Fecha,
            'CPF'=>$CP->Fecha,
            'PANF'=>$PAN->Fecha,
            'PTP'=>$Acta->PT,
            'IGP'=>$Acta->IG,
            'CPP'=>$Acta->CP,
            'PANP'=>$Acta->PAN,
            'BodyProduc'=> $BodyProduc,
            'Embarcacion'=>  $Embarcacion,
            'VMarca'=>$Valvula->Marca,
            'VModelo'=>$Valvula->Modelo,
            'VSerial'=>$Valvula->Serial,
            'VFabricacion'=> $Valvula->FabricaciÃ³n,
            'VTipo'=> $Valvula->Tipo,
            'VOpera'=>$Valvula->Opera,
            'VFecha'=>  $FechaI,
            'VVence'=>$FechaV,
            'Year'=>$Year,
            'Codigo'=>   Digitos($Orden[0]->Insumos,4),
            'Observacion'=>  $Observacion,


            
        );
       
       
          $this->load->view('header');
          $this->load->view('CertificadoBalsa',$data);
          $this->load->view('footer');
          return;
        }
        $Balsa = $this->RaftModels->getRaftFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0].'|StatusCertificado^Activo',1,0,0,"1",'s0|12|13');
        if(count($Balsa)>0){
            header("Content-type: application/pdf");
            header("Content-Disposition: inline; filename=documento.pdf");
            readfile( $Dir.'certificadobalsas/'.$parametros[0].'.pdf');
            return;
        }else{
         
            echo "Balsa Sin Certificado";
            return;
        } 
       
      
       
      } 
       
    }
    function BuscarDentro($Array,$Palabra){
      $AuxP = mb_strtoupper($Palabra);
      $respu = false;
    
      for ($i=0;$i < count($Array); $i++){
       
        if( mb_strtoupper($Array[$i]) ===  $AuxP )
        $respu = true;
      }
      return $respu;
     }
    function BodyTabla($arr,$Titulos){
     
      $Fi = "";
      foreach ($arr as $Fila){
        $Fi=  $Fi.'<tr>';
        $Colum= '';
     
        
             for( $i=0; $i< count($Titulos); $i++  ){
              foreach (  $Fila as $key => $val){
              if( $Titulos[$i] ===$key){
                $Colum =  $Colum. '<td ><FONT SIZE="3"> '. $val.' </FONT></td>';
              }
            }
            }
        
        $Fi= $Fi.$Colum.'</tr>';
      }
    return $Fi;
    }
    
    protected function middleware()
    {
      return ["VerificacionDB"];
    }
    }
    /* end CertificadoBalsaCtrl.php file for CodeIgniter TCPDF Integration */
    ?>