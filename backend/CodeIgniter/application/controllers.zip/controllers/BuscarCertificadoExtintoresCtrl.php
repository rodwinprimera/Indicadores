<?php class BuscarCertificadoExtintoresCtrl extends MY_Controller { 
    
    function __construct() {
      
      
    parent::__construct(); 
    // add library of Pdf 
    $this->load->library('Pdf');
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    }
    
    
    public function _remap($met,$parametros = array()){
    
      $method = $_SERVER['REQUEST_METHOD'];
   
     if($met ==="index"){
    
      switch ($method)  
      { case 'PUT':
         // $this->Edit(); 
        break;
        case 'POST': 
          //$this->Add();
        break;
        case 'GET': 
          
          $this->GestionCertificado($parametros);
        case 'HEAD': 
          // echo json_encode( $method );
        break; 
        case 'DELETE': 
         // $this->Delete($parametros); 
        break; 
        case 'OPTIONS': 
         // echo json_encode( $method );
       break; 
       default: 
       echo json_encode( "Error" );
       break; 
      }
    }
    
    
     }
    
    
    
 

    
    public function GestionCertificado($parametros)
    {
     
      $Dir = Raiz();
      // primero verificamos si el usuario esta logueado y de estarlo dejamos que descargue el pdf
    

      $Token = FALSE;
      $Header =  $this->input->request_headers();
      if(isset($Header['Authorization'])){
          $Authorization= $Header['Authorization'];
          if(  $Authorization !=""){
              $Authorization =str_replace('Bearer ','', $Authorization);
              $Token = ValidarToken($Authorization);
          }
      }
      if ( $Token === FALSE ){
        $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
      
       
        $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
        $Token  =$DatosGET!=''?$DatosGET: $Token ;
        
       }
       if(isset($this->session)){
        $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
     }else{
        $ID =   $Token== FALSE ? null :  $Token ;
     }
       $DatosGET ="";
       if ($ID === null && $Token === FALSE ){
        $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
        $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
       }
      if( $ID === null AND  $DatosGET ===""){
        if(count($parametros) ===1){
         $Extintor = $this->ExtinguisherModels->getExtinguisherFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0],1,0,0,"1",'s0|1|2|3|4|5|6|7|8|9|10|11|12');
         if(count($Extintor)>0){
          
      }else{
          echo "Extintor sin Certificado";
          return;
      }
   
         $Extintor = $this->ExtinguisherModels->getExtinguisher($Extintor[0]->ID); 
        // return print_r($Extintor);
        } 
        $DatosArmador  = $this->ClientModels->getClient($Extintor[0]->Armador);
  $Agente= [""=>"","1"=>"CO2","2"=>"PQS","3"=>"ALOTRON","4"=>"AGUA","5"=>"CLORURO DE POTACION", "6"=>"CLORURO DE SODIO","7"=>"AGUA + ESPUMA QUIMICA"];
  $na= 'Embarcacion-Lugar';
  $Cer = 'CESMEC-IDIEM';
  $AgenteExtintor = $Agente[$Extintor[0]->Tipo];
  $CESMEC = $Extintor[0]->$Cer;
  $Embarcacion =  $Extintor[0]->$na;
  $Armador =  $DatosArmador[0]->Nombre.' '. $DatosArmador[0]->Apellidos;
  $Capacidad = $Extintor[0]->Capacidad;
  $Serial = $Extintor[0]->Serial;
  $CerAnt = $Extintor[0]->Certificado;
  $Tipo = $Extintor[0]->Tipo;
  $Email =  $DatosArmador[0]->Correo;
  $Vence =  $Extintor[0]->Vence;
  $Year =  date("Y",strtotime($Extintor[0]->Modificado));
   
        //return  print_r($Extintor);
        $Titulo = array('Embarcacion/lugar' => "Hola",'Hola'=>"" );
        $Extintor[0]->Elementos= str_replace('Titulo','ELEMENTOS INSPECCIONADOS',$Extintor[0]->Elementos);
        $Extintor[0]->Elementos= str_replace('Obs',utf8_encode('Observación'),$Extintor[0]->Elementos);
        $Arrayobj = [];
       $obj= json_decode($Extintor[0]->Elementos, true);
        foreach ($obj as $Key=> $val){
          $dato = [];
          $Datos2=[];
         foreach ($val as $Key2=> $val2){
           if ($Key2=== 'Status')
           {
             
             $dato['Si'] = ($val2 == true) ? 'X': '';
             $dato['No'] = ($val2 == '' OR  $val2 == false ) ? "X": " ";
           }else{
             $dato[$Key2] = $val2;
           }
           
         }
         $Titulos = array_keys($dato);
         
          for( $i=0; $i< count($Titulos); $i++  ){
           $Datos2[$Titulos[$i]] =  $dato[$Titulos[$i]];
          }
          
     
         $Arrayobj[$Key] = $Datos2;
       }
     
       $BodyElementos=  $this->BodyTabla( $Arrayobj);
       $data = array(
        'Saludo'=> 'Hola Mundo',
        'Embarcacion'=>  $Embarcacion,
        'Capacidad'=>   $Capacidad ,
        'Armador'=> $Armador,
        'AgenteExtintor'=> $AgenteExtintor,
        'CESMEC'=>   $Cer,
        'Codigo'=>   Digitos($Extintor[0]->ID,4),
        'Year' =>  $Year,
        'tabla'=>  $BodyElementos,
        'Vence' =>  $Vence,
    );
      
        $this->load->view('header');
        $this->load->view('CertificadoExtintor',$data);
        $this->load->view('footer');
        return;
      }
 
     
      if(count($parametros) ===1){ 
       
        $Extinguisher = $this->ExtinguisherModels->getExtinguisherFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0],1,0,0,"1",'s0|1|2');
        if(count($Extinguisher)>0){
            header("Content-type: application/pdf");
            header("Content-Disposition: inline; filename=documento.pdf");
            readfile($Dir.'CertificadoExtintores/'.$parametros[0].'.pdf');
            return;
        }else{
            $Extinguisher = $this->ExtinguisherModels->getExtinguisherFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0],1,0,0,"1",'s0|1|2');
            if(count($Extinguisher)>0){
                header("Content-type: application/pdf");
                header("Content-Disposition: inline; filename=documento.pdf");
                readfile($Dir.'CertificadoExtintores/'.$parametros[0].'.pdf');
                return;
            }else{
                echo "Extintor sin Certificado";
                return;
            }
           
        } 
       
      
       
      } 
       
    }
    
    function BodyTabla($arr){
  
      $arrayTitulo = [];
      $arrayTituloImprimir = "";
      $posT =0;
      $arrayTituloImprimir ="<tr>";
      $Fi = "";
      foreach (  $arr[0] as $key => $val){
        $arrayTitulo[$posT] = $key;
        if($key=='Si' OR $key== 'No'){
          $arrayTituloImprimir=$arrayTituloImprimir.'<th WIDTH= "5%" ><FONT SIZE="3"><b>'.utf8_decode($key).'</b></FONT></th>';
          
        }else{
          $arrayTituloImprimir=$arrayTituloImprimir.'<th WIDTH= "45%" ><FONT SIZE="3"><b>'.utf8_decode($key).'</b></FONT></th>';
        }
       
        $posT++;
      }
      $arrayTituloImprimir =$arrayTituloImprimir."</tr>";
      foreach ($arr as $Fila){
        $Fi=  $Fi.'<tr>';
        $Colum= '';
     
        
             for( $i=0; $i< count($arrayTitulo); $i++  ){
              foreach (  $Fila as $key => $val){
              if( $arrayTitulo[$i] ===$key){
                $Colum =  $Colum. '<td ><FONT SIZE="3"> '. $val.' </FONT></td>';
              }
            }
            }
        
        $Fi= $Fi.$Colum.'</tr>';
      }
    return $arrayTituloImprimir.$Fi;
    }
    
    protected function middleware()
    {
      return ["VerificacionDB"];
    }
    }
    /* end CertificadoBalsaCtrl.php file for CodeIgniter TCPDF Integration */
    ?>