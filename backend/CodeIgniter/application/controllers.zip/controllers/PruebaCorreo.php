<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PruebaCorreo extends MY_Controller {
  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
  }
	public function index()
	{
        
       
        
        
    if(isset($this->session)){
     
      $data = array(
        "User"=> "id", //Guardaremos el user o el id si se a logeado correctamenteo;
         "intentos"=> 0, // valor de intentos al loguearse
         "login" => true
    );
    $this->session->set_userdata($data); //guardamos la session
    $this->session->userdata("login");
}

      
	}
    public function _remap($met,$parametros = array()){

        $method = $_SERVER['REQUEST_METHOD'];
         
        switch ($method)  
        { 
          case 'POST': 
    
          break;
          case 'GET': 
            $htmlContent = '<h1>Prueba De Correo</h1>';
            $htmlContent .="<p>Prueba</p>";
            EmailHtml("Rodwinprimera1@gmail.com","Prueba De Correo", $htmlContent);
            echo "Hola";
            break; 
          case 'DELETE': 
           
          break; 
         default: 
         echo json_encode( "Error" );
         break; 
        }
       }
 



}