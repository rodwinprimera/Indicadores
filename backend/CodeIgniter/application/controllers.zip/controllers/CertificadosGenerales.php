<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class CertificadosGenerales extends MY_Controller {
function __construct() {
  
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header('content-type: application/json; charset=utf-8');
  $method = $_SERVER['REQUEST_METHOD'];
  if($method == "OPTIONS") {
      die();
  }
parent::__construct(); 
// add library of Pdf 
$this->load->library('Pdf');
}


public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];
  if($met ==="Alarma"){
  
    $this->Alarma();
   }

 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
     // $this->Edit(); 
    break;
    case 'POST': 
      //$this->Add();
    break;
    case 'GET':
      $this->GestionCertificado($parametros);
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
     // $this->Delete($parametros); 
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }



private function Verificar($Nombre,$DB = ""){
    $Ordenaux = $this->OrdenesGModels->getOrdenesGFiltro("s10"."^".$Nombre);
   if(count($Ordenaux) > 0){
     return $this->Verificar(Random($DB));
  }else{
    return $Nombre;
  }
 
}

private function Tipo($value){
 switch ($value) {
  case '1':
    # code...
  return "INSPECCION BANCO CO2";
  case '2':
    # code...
  return "INSPECCION TRAJE INMERSION";
  default:
    # code...
    return " INSPECCION BANCO EXTINCION INCENDIO";
 }
}
public function Alarma(){
  $ArrayPorVencer = $this->OrdenesGModels->Alarma();

  foreach ($ArrayPorVencer as $Fila){
  
    $Serial = $Fila->Certificado;
    $DatosEditar = '{"0":"'. $Fila->ID.'", "11":"5"}';
    $DatosEditar =  json_decode($DatosEditar, true);
    $isn= $this->OrdenesGModels->Edit($DatosEditar);
    
  if($Fila->Correo != ""){
 $Tipo=   $this->Tipo($Fila->Tipo);
    $htmlContent = '<h1>Certificado De '.$Tipo.'</h1>';
    $htmlContent .="<p> Codigo: $Serial, Esta Por VENCER actualmente tiene una vigencia de 30 dias.</p>";
    //EmailHtml($Fila->Correo,"SEGMARIND ADVERTENCIA", $htmlContent);
  };
  }

  $ArrayVencidas = $this->OrdenesGModels->Alarma2();
 
  foreach ($ArrayVencidas as $Fila){
   
    $DatosEditar = '{"0":"'. $Fila->ID.'","11":"3"}';
      $DatosEditar =  json_decode($DatosEditar, true);
     
      $isn= $this->OrdenesGModels->Edit($DatosEditar);
    if($Fila->Correo != ""){
  
      $Serial = $Fila->Certificado;
      $Tipo=   $this->Tipo($Fila->Tipo);
      $htmlContent = '<h1>Certificado De '.$Tipo.'</h1>';
      $htmlContent .="<p>: $Serial, Esta Vencidad actualmente deber renovar su certificado .</p>";
      //Html($Fila->Correo,"SEGMARIND ADVERTENCIA", $htmlContent);
   
      $this->MinutesModels->Edit($DatosEditar);
      
    };
    }

}


private function GetPremisos(){
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
if(isset($this->session)){
    $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
}else{
    $ID =   $Token== FALSE ? null :  $Token ;
}

  $User = $this->UserModels->getUser($ID);
  $Nivel =$User[0]->Nivel;
  $Permiso= $this->db->get_where('detalleniveles',array("Status"=>"Activo","Ruta"=>"Inspetor","Nivel"=>$Nivel))->result();
  $per =0;
  if(  count($Permiso)>0){
  return $Permiso[0]->Permiso;
}else{
  return 0;
}

}
public function GestionCertificado($parametros)
{
  /*
  
1 En Proceso
2 Activo
3Vemcido
4 Eliminado
5 Por Vencer Notificado

  */
  $FirmanteInterno=0;
  $Nombre = "";
  $Dir = Raiz(); 
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
  if(isset($this->session)){
    $User =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
  }else{
    $User =  $Token== FALSE ? null:  $Token ;
  }
 
  if(count($parametros) ===0){ 
    echo "Debe enviar acta";
    return;
  } 
  if(DbMultiple== TRUE){ 
    $Nombre = $this->Verificar(Random($this->UserDB), $this->UserDB);
    
  }else{
    $Nombre = $this->Verificar(Random());
  }
  $OrdenG = $this->OrdenesGModels->getOrdenesG($parametros[0]); 

    if( $OrdenG != null AND  count($parametros) ===1 ){
      if($OrdenG[0]->Status == 2){
        header("Content-type: application/pdf");
        header("Content-Disposition: inline; filename=documento.pdf");
        readfile($Dir.'CertificadosGenerales/'.$OrdenG[0]->Certificado.'.pdf');
        return;
      }
      
  } 
  if( count($OrdenG) === 0){
    echo "Certificado no existe";
    return;
  }
  $CodigoPlanilla =Digitos($OrdenG[0]->ID,4);
  

  $Fecha=$OrdenG[0]->Fecha;
  $Vence = $OrdenG[0]->Vence;
  if(count($parametros) ===2){
    
    
     // Buscamos los datos del usuario
    $permiso= $this->GetPremisos();
  if($permiso == 1){
    $FirmanteInterno = random_int(1, 5);
  }
   
  
  if (Existe($Dir.'/Firmas/'. $FirmanteInterno.".png") === false){
    echo(json_encode(array("Error"=>"Firma no existe")));
    return ;
  }else{

  }
// Verificamos quien firmara el documento segun si nivvel 
  if($permiso == 1){
    // ispector empresa
   
   // if($Extintor[0]->Inspector == null){
      // si no existe firma del ispector y existe un documento lo eliminamos para crear uno de nuevo
      if(Existe($Dir.'CertificadosGenerales/'.$OrdenG[0]->Certificado.'.pdf')=== true){
      //  unlink($Dir.'CertificadoExtintores/'.$Extintor[0]->Certificado.'.pdf');
      }
   // }else{
      // de existir firma es por que ya el documento fue firmado por un inspector
    //  echo(json_encode(array("Error"=>"Documento Firmado")));
    //  return;
   // }
  
    
  }else{
    echo(json_encode(array("Error"=>"No autorizado")));
    return ;
  }
 
 
 
  }else{
    // si no desea firmar documento igual preguntamos las firmas
  }

 

  // verificamos si ya existe un documento creado y guardamos el nombre
 // $Nombre = $Extintor[0]->Certificado != ""? $Extintor[0]->Certificado :$Nombre;

 if ($OrdenG[0]->Certificado != "" and Existe($Dir.'CertificadosGenerales/'.$Nombre.'.pdf') AND count($parametros) ===1  ){
  // si existe el documento lo mandamos a mostrar
  // y como lo eliminamos previamente de querer crear la firma no hay problema
  header("Content-type: application/pdf");
  header("Content-Disposition: inline; filename=documento.pdf");
  readfile($Dir.'CertificadosGenerales/'.$OrdenG[0]->Certificado.'.pdf');
  return;
 }
// buscamos la informacion que llevara el certificado



 $DatosArmador  = $this->ClientModels->getClient($OrdenG[0]->Armador);
 $Armador =  $DatosArmador[0]->Nombre.' '. $DatosArmador[0]->Apellidos;
   
 $Email =  $DatosArmador[0]->Correo;
  $FechaI = $Fecha;
  $Year = date("Y");
  $Embarcacion = $OrdenG[0]->Lugar_Buque;
  $Bandera =$OrdenG[0]->Bandera;
  $Lugar = $OrdenG[0]->Lugar;
  $NOTA = "Nota";
  $Obs = $OrdenG[0]->Observacion;
  if($Obs != ""){
    $Obs  = str_replace("\n", '<FONT/><FONT style= " display:block;" SIZE="9"><br>', $Obs);
    $Obs = ' <FONT SIZE="9"> Observaciones: <FONT/>  <FONT style= " display:block;" SIZE="9"><br>'.$Obs . '<FONT/>';
  }

  $Detalle =   json_decode(utf8_encode($OrdenG[0]->Elementos), true); 
  if(count($Detalle)===0)return;

  $BodyElementos=  $this->BodyTabla($Detalle ); 
   
     
// coder for CodeIgniter TCPDF Integration
// make new advance pdf document
$tcpdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
 
// set document information

$tcpdf->SetAuthor('segmarind');
$tcpdf->SetTitle('Certificados');
$tcpdf->SetSubject('segmarind');
$tcpdf->SetKeywords('TCPDF, PDF, segmarind, test, guide');
 
//set default header information
 
$tcpdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, "", "", array(0,65,256), array(0,65,127));


$tcpdf->setFooterData(array(0,65,0), array(0,65,127));
 
//set header  textual styles
$tcpdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//set footer textual styles
$tcpdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
 
//set default monospaced textual style
$tcpdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
 
// set default margins
$tcpdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
// Set Header Margin
$tcpdf->SetHeaderMargin(PDF_MARGIN_HEADER);
// Set Footer Margin
$tcpdf->SetFooterMargin(PDF_MARGIN_FOOTER);
 
// set auto for page breaks
$tcpdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image for scale factor
$tcpdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// it is optional :: set some language-dependent strings
if (@file_exists(dirname(__FILE__).'/lang/eng.php'))
{
// optional
require_once(dirname(__FILE__).'/lang/eng.php');
// optional
$tcpdf->setLanguageArray($l);
}
 
// set default font for subsetting mode
$tcpdf->setFontSubsetting(true);



// Set textual style
// dejavusans is an UTF-8 Unicode textual style, on the off chance that you just need to
// print standard ASCII roasts, you can utilize center text styles like
// helvetica or times to lessen record estimate.
//$tcpdf->SetFont('dejavusans', '', 14, '', true);
 
// Add a new page
// This technique has a few choices, check the source code documentation for more data.
$tcpdf->AddPage();





// set text shadow for effect
/*
$tcpdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,197,198), 'opacity'=>1, 'blend_mode'=>'Normal'));
 
//Set some substance to print
 */
$set_html = "";
if($OrdenG[0]->Tipo == 1){

$set_html = <<<EOD
<h3  style="text-align: center;">CERTIFICADO DE INSPECCION BANCO CO2</h3>
<h4  style="text-align: center;">SMI  $CodigoPlanilla/$Year</h4>

<table border="1"   >

<tr>
<td  WIDTH= "33%" height = "50PX"  ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Nombre Buque</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Embarcacion</FONT></td>
<td  WIDTH= "33%" height = "50PX" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Bandera</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Bandera</FONT></td>
<td  WIDTH= "33%" height = "50PX"><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Armador</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Armador</FONT></td>
</tr>
<tr>
<td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Fecha</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Fecha</FONT></td>
<td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Lugar</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Lugar</FONT></td>
<td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Vencimiento</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Vence</FONT></td>
</tr>


</table>

<h5  style="text-align: justify; ">El abajo firmante, Inspector debidamente autorizado, certifica que el presente banco de CO2, ha sido inspeccionado y mantenido de acuerdo a las especificaciones técnicas que les rige, N.CH 2056 y Circulares DGTM 0-71/024 y O-71/026, marcando con etiquetas de servicio y dejado en condiciones satisfactorias para su debido uso. </h5>
<FONT style= "text-align: center; display:block;" SIZE="9"><b>INSPECCION DE LOS CILINDROS DE CO2</b></FONT><br>
<table   border="1" >


$BodyElementos

</table>


<FONT SIZE="10" >NOTA: </FONT><br>

<table border="0"   >
<tr>
<td>
<FONT SIZE="9" >IE	=	Inspección Externa</FONT><br>
<FONT SIZE="9" >R	=	Recarga</FONT><br>
<FONT SIZE="9" >PH  =	Prueba Hidrostática</FONT><br>
<FONT SIZE="9" >CP  =	Control de Peso</FONT><br>
<FONT SIZE="9" >IC  =	Inspección Circuito</FONT><br>
</td>

<td>
<FONT SIZE="9" >CN	=	Control Niveles Co2 Portalevel</FONT><br>
<FONT SIZE="9" >CA	=	Cambio Adhesivos</FONT><br>
<FONT SIZE="9" >RP  =	Rascado y Pintado</FONT><br>
<FONT SIZE="9" >AL  =	Control Alarma</FONT><br>
<FONT SIZE="9" >IAR  =	Inspección Accionamiento Remoto</FONT><br>
</td>
</tr>
</table>
 
$Obs
EOD;


}

if($OrdenG[0]->Tipo == 2){
  $set_html = "";
  $set_html = <<<EOF
  <h3  style="text-align: center;">CERTIFICADO DE INSPECCION TRAJE INMERSION</h3>
  <h4  style="text-align: center;">ITI $CodigoPlanilla/$Year</h4>
  
  <table border="1"   >
  
  <tr>
  <td  WIDTH= "33%" height = "50PX"  ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Nombre Buque</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Embarcacion</FONT></td>
  <td  WIDTH= "33%" height = "50PX" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Bandera</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Bandera</FONT></td>
  <td  WIDTH= "33%" height = "50PX"><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Armador</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Armador</FONT></td>
  </tr>
  <tr>
  <td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Fecha</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Fecha</FONT></td>
  <td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Lugar</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Lugar</FONT></td>
  <td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Vencimiento</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Vence</FONT></td>
  </tr>
  
  
  </table>
  
  <h5  style="text-align: justify; ">El abajo firmante, Inspector debidamente autorizado, certifica que los siguientes trajes de inmersión, han sido inspeccionado y mantenido de acuerdo a las especificaciones técnicas que les rige, N.CH 2056 y Circulares DGTM 0-71/024 y O-71/026, marcando con etiquetas de servicio y dejado en condiciones satisfactorias para su debido uso. </h5>
  <FONT style= "text-align: center; display:block;" SIZE="9"><b>INSPECCION DE TRAJES DE INMERSION</b></FONT><br>
  <table   border="1" >
  
  
  $BodyElementos
  
  </table>
  
  
  <FONT SIZE="10" >NOTA: </FONT><br>
  
  <table border="0"   >
  <tr>
  <td>
  <FONT SIZE="9" >DC	=	Deslizamiento Cierre</FONT><br>
  <FONT SIZE="9" >LE	=	Luz Estroboscópica</FONT><br>
  <FONT SIZE="9" >ET  =	Estanqueidad Traje</FONT><br>
  <FONT SIZE="9" >CA  =	Cambio Adhesivos</FONT><br>
  </td>

  </tr>
  </table>
  
  

  $Obs
  
  
EOF;

  }



  if($OrdenG[0]->Tipo == 3){
    $set_html = "";
    $set_html = <<<EOL
    
    <h3  style="text-align: center;">CERTIFICADO DE INSPECCION BANCO EXTINCION INCENDIO</h3>
    <h4  style="text-align: center;">SMI  $CodigoPlanilla/$Year</h4>
    
    <table border="1"   >
    
    <tr>
    <td  WIDTH= "33%" height = "50PX"  ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Nombre Buque</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Embarcacion</FONT></td>
    <td  WIDTH= "33%" height = "50PX" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Bandera</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Bandera</FONT></td>
    <td  WIDTH= "33%" height = "50PX"><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Armador</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Armador</FONT></td>
    </tr>
    <tr>
    <td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Fecha</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Fecha</FONT></td>
    <td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Lugar</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Lugar</FONT></td>
    <td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="9"><b>Vencimiento</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="9"> $Vence</FONT></td>
    </tr>
    
    
    </table>
    
    <h5  style="text-align: justify; ">El abajo firmante, Inspector debidamente autorizado, certifica que el presente banco de CO2, ha sido inspeccionado y mantenido de acuerdo a las especificaciones técnicas que les rige, N.CH 2056 y Circulares DGTM 0-71/024 y O-71/026, marcando con etiquetas de servicio y dejado en condiciones satisfactorias para su debido uso. </h5>
    <FONT style= "text-align: center; display:block;" SIZE="9"><b>INSPECCION DE LOS CILINDROS </b></FONT><br>
    <table   border="1" >
    
    
    $BodyElementos
    
    </table>
    
    
    <FONT SIZE="10" >NOTA: </FONT><br>
    
    <table border="0"   >
    <tr>
    <td>
    <FONT SIZE="9" >IE	=	Inspección Externa</FONT><br>
    <FONT SIZE="9" >R	=	Recarga</FONT><br>
    <FONT SIZE="9" >PH  =	Prueba Hidrostática</FONT><br>
    <FONT SIZE="9" >CP  =	Control de Peso</FONT><br>
    <FONT SIZE="9" >PL  =	Prueba Portalevel Ultrasonido</FONT><br>
    </td>
  
    </tr>
    </table>
    
    $Obs
EOL;
  }


//Print content utilizing writeHTMLCell()

 $tcpdf->writeHTMLCell(0, 0, '', '', $set_html, 0, 1, 0, true, '', true);
 $y_start = $tcpdf->GetY();
 //$page_start = $tcpdf->GetY();
 if($y_start > 245){
    $tcpdf->AddPage();
 }
 //print($y_start);
 if($FirmanteInterno != "Nada"){
    $tcpdf->Image( $Dir.'/Firmas/'.$FirmanteInterno.".png", 130, 205, 60);
  }
  
 
$tcpdf->SetFont("", 'B', 10);
$tcpdf->MultiCell(70,5, "
      DISTRIBUCIÓN COPIAS:
      1-CLIENTE  2- SEGMARIND
  ", 0, 'C', 0, 0, '', 235, true, 0, false, false, 35, 'M', false);



  $tcpdf->MultiCell(70,5, "____________________________
  Inspector Autorizado
      SEGMARIND LTDA
  D.S. y O.M.ORD.N°12600/447 VRS
 ", 0, 'C', 0, 1, 125, 235, true, 0, false, false, 40, 'M', false);

 $tcpdf->SetFont("", '', 8);
 $MI_HOST = $this->ConfigModels->Value('MI_HOST');
$tcpdf->MultiCell(175,5, "Puede verificar la valides de este documiento en: ".$MI_HOST."Sistema/Certificados Debe usar el Código: $Nombre ", 0, 'C', 0, 0, 10, 265, true, 0, false, false, 35, 'M', true);
$tcpdf->SetFont("", 'B', 10);
$style = array(
    'border' => 0,
    'vpadding' => 'auto',
    'hpadding' => 'auto',
    'fgcolor' => array(0,0,0),
    'bgcolor' => array(255,255,255),
    'module_width' => 1, // width of a single module in points
    'module_height' => 1 // height of a single module in points
  );
  $MI_HOST = $this->ConfigModels->Value('MI_HOST');
  $tcpdf->write2DBarcode($MI_HOST.'CodeIgniter/Certificados/'.$Nombre.'', 'QRCODE,Q', 90, 245, 20, 20, $style, 'C');
 switch (count($parametros)) { 
  
  case 0:
    break;
  case 1:
    $tcpdf->Output('Certificado.pdf', 'I');
  break;
  case 2:
  
   if (Existe($Dir.'/CertificadosGenerales/') === false){
    CrearCarpeta($Dir.'/CertificadosGenerales/');
   
    
   }
   
    $tcpdf->Output($Dir.'/CertificadosGenerales/'.$Nombre.'.pdf', 'F');
    if( $FirmanteInterno != 'Nada' ){
      //$DatosArmador aqui enviamos los datos del certificado
      // actualizamos la fecha de vencimiento  a un ano 
      $Datos = array(0=>$OrdenG[0]->ID,2=>$User,10=>$Nombre,11=>2);
      $this->OrdenesGModels->Edit($Datos);
 $htmlContent = '<h1>Certificado </h1>';
 
       if($Email != ""){
       
       EmailHtml($Email,"SEGMARIND CERTIFICADO", $htmlContent,$Dir.'/CertificadosGenerales/'.$Nombre.'.pdf');

       }
    
       

       

       
        
    }
   
    
    header("Content-type: application/pdf");
    header("Content-Disposition: inline; filename=documento.pdf");
    readfile($Dir.'CertificadosGenerales/'.$Nombre.'.pdf');
   
  
    return;
    
    break;
  }





//
// successfully created CodeIgniter TCPDF Integration
}

function BodyTabla($arr){
  
  $arrayTitulo = [];
  $arrayTituloImprimir = "";
  $posT =0;
  $arrayTituloImprimir ="<tr>";
  $Fi = "";
  foreach (  $arr[0] as $key => $val){
    $arrayTitulo[$posT] = $key;
    if($key=='Si' OR $key== 'No'){
      $arrayTituloImprimir=$arrayTituloImprimir.'<th ><FONT SIZE="8" style= "text-align: center;" ><b>'.utf8_decode($key).'</b></FONT></th>';
      
    }else{
      $arrayTituloImprimir=$arrayTituloImprimir.'<th ><FONT SIZE="8" style= "text-align: center;" ><b>'.utf8_decode($key).'</b></FONT></th>';
    }
   
    $posT++;
  }
  $arrayTituloImprimir =$arrayTituloImprimir."</tr>";
  foreach ($arr as $Fila){
    $Fi=  $Fi.'<tr>';
    $Colum= '';
 
    
         for( $i=0; $i< count($arrayTitulo); $i++  ){
          foreach (  $Fila as $key => $val){
          if( $arrayTitulo[$i] ===$key){
            $Colum =  $Colum. '<td ><FONT SIZE="8" style= "text-align: center;" > '. $val.' </FONT></td>';
          }
        }
        }
    
    $Fi= $Fi.$Colum.'</tr>';
  }
return $arrayTituloImprimir.$Fi;
}

protected function middleware()
{
 
 return [];
}
}
/* end CertificadoExtintoresCtrl.php file for CodeIgniter TCPDF Integration */