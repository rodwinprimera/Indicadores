<?php class BuscarCertificadoAperturaCtrl extends MY_Controller { 
    
    function __construct() {
      
      header('Access-Control-Allow-Origin: *');
      header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
      header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
      header("Allow: GET, POST, OPTIONS, PUT, DELETE");
      header('content-type: application/json; charset=utf-8');
      $method = $_SERVER['REQUEST_METHOD'];
      if($method == "OPTIONS") {
          die();
      }
    parent::__construct(); 
    // add library of Pdf 
    $this->load->library('Pdf');
    }
    
    
    public function _remap($met,$parametros = array()){
    
      $method = $_SERVER['REQUEST_METHOD'];
    
    
     if($met ==="index"){
    
      switch ($method)  
      { case 'PUT':
         // $this->Edit(); 
        break;
        case 'POST': 
          //$this->Add();
        break;
        case 'GET': 
          $this->GestionCertificado($parametros);
        case 'HEAD': 
          // echo json_encode( $method );
        break; 
        case 'DELETE': 
         // $this->Delete($parametros); 
        break; 
        case 'OPTIONS': 
         // echo json_encode( $method );
       break; 
       default: 
       echo json_encode( "Error" );
       break; 
      }
    }
    
    
     }
    
    
    
 

    
    public function GestionCertificado($parametros)
    {
      $Dir = Raiz();
     
      if(count($parametros) ===1){ 
       
        $Minutes = $this->MinutesModels->getMinutesFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0],1,0,0,"1",'s0|1|2');
        if(count($Minutes)>0){
            header("Content-type: application/pdf");
            header("Content-Disposition: inline; filename=documento.pdf");
            readfile( $Dir.'CertificadoAperturas/'.$parametros[0].'.pdf');
            return;
        }else{
            $Minutes = $this->MinutesModels->getMinutesFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0],1,0,0,"1",'s0|1|2');
            if(count($Minutes)>0){
                header("Content-type: application/pdf");
                header("Content-Disposition: inline; filename=documento.pdf");
                readfile( $Dir.'CertificadoAperturas/'.$parametros[0].'.pdf');
                return;
            }else{
                echo "Balsa Sin Certificado de Acta de Apertura";
                return;
            }
           
        } 
       
      
       
      } 
       
    }
    
    function BodyTabla($arr,$Titulos){
     
      $Fi = "";
      foreach ($arr as $Fila){
        $Fi=  $Fi.'<tr>';
        $Colum= '';
     
        
             for( $i=0; $i< count($Titulos); $i++  ){
              foreach (  $Fila as $key => $val){
              if( $Titulos[$i] ===$key){
                $Colum =  $Colum. '<td ><FONT SIZE="8"> '. $val.' </FONT></td>';
              }
            }
            }
        
        $Fi= $Fi.$Colum.'</tr>';
      }
    return $Fi;
    }
    
    protected function middleware()
    {
      return ["VerificacionDB"];
    }
    }
    /* end CertificadoBalsaCtrl.php file for CodeIgniter TCPDF Integration */
    ?>