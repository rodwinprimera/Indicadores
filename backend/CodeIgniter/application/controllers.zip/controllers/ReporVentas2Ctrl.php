<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ReporVentas2Ctrl extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];

 switch ($met)  
 { case 'Buscar1':
     $this->Buscar1($parametros); 
     break;
   case 'Buscar2': 
     $this->Buscar2($parametros);   
   break;
   case 'Buscar3': 
     $this->Buscar3($parametros); 
   break; 
   case 'Buscar4': 
    $this->Buscar4($parametros);
   break; 
   case 'Buscar5': 
    $this->Buscar5($parametros);
   break; 
   case "MetaData":
    $this->MetaData($parametros);
   break;

 }
 if($met ==="index"){

  switch ($method)  
  { case 'GET': 
      $this->Search($parametros);
    break;
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }
    



// aqui viene los metodos de buscar



private function Search($Arr =array() ){
  $Asignacion =array();
  switch (count($Arr)) 
  { case 0:
    $Asignacion= $this->ReporVentasModels->getReporVentas();
    $Asignacion2= $this->ReporteVentasModels2->getReporVentas();
    $Asignacion = array_merge($Asignacion, $Asignacion2);
    break;
    case 1: 
      $Asignacion = $this->ReporVentasModels->getReporVentas($Arr[0]);
      $Asignacion2= $this->ReporteVentasModels2->getReporVentas($Arr[0]);
      $Asignacion = array_merge($Asignacion, $Asignacion2);
    break;
    case 2: 
      $Asignacion = $this->ReporVentasModels->getReporVentasLimite($Arr[0],$Arr[1]);
      $Asignacion2= $this->ReporteVentasModels2->getReporVentas();
      $Asignacion = array_merge($Asignacion, $Asignacion2);
      break; 
    case 4: 
      $Asignacion = $this->ReporVentasModels->getReporVentasLimiteOrden($Arr[0],$Arr[1],$Arr[2],$Arr[3]);
      $Asignacion2= $this->ReporteVentasModels2->getReporVentas();
      $Asignacion = array_merge($Asignacion, $Asignacion2);
    break; 
    case 5: 
      $Asignacion = $this->ReporVentasModels->getReporVentasLimiteOrdenColumnas($Arr[0],$Arr[1],$Arr[2],$Arr[3],urldecode($Arr[4]));
      $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltroColumnas('s',urldecode($Arr[4]));
      $Asignacion = array_merge($Asignacion, $Asignacion2);
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion); 
}

private function Buscar1 ($Arr = array()){
  $Asignacion =array();
  switch (count($Arr)) 
  {
    case 1: 
      $Asignacion = $this->ReporVentasModels->getReporVentasFiltro(urldecode($Arr[0]
    ));
    $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltro(urldecode($Arr[0]));
    $Asignacion = array_merge($Asignacion, $Asignacion2);
    break;
    case 3: 
      $Asignacion = $this->ReporVentasModels->getReporVentasFiltroLimite(urldecode($Arr[0]),$Arr[1],$Arr[2]);
      $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltro(urldecode($Arr[0]));
      $Asignacion = array_merge($Asignacion, $Asignacion2);
    break; 
    case 5: 
      $Asignacion = $this->ReporVentasModels->getReporVentasFiltroLimiteOrden(urldecode($Arr[0]),$Arr[1],$Arr[2],$Arr[3],$Arr[4]);
      $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltro(urldecode($Arr[0]));
      $Asignacion = array_merge($Asignacion, $Asignacion2);
   break; 
   case 6: 
    $Asignacion = $this->ReporVentasModels->getReporVentasFiltroLimiteOrdenColumnas(urldecode($Arr[0]),$Arr[1],$Arr[2],$Arr[3],$Arr[4],urldecode($Arr[5]));
    $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltro(urldecode($Arr[0]));
    $Asignacion = array_merge($Asignacion, $Asignacion2);
    break; 
   default: 
   echo json_encode( $Arr );
   break; 
  }
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion); 
  
}
private function Buscar2 ($Arr =array()){
  $Asignacion =array();
  $Asignacion = $this->ReporVentasModels->getReporVentasFiltroColumnas(urldecode($Arr[0]),urldecode($Arr[1]));
  $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltroColumnas(urldecode($Arr[0]),urldecode($Arr[1]));
  $Asignacion = array_merge($Asignacion, $Asignacion2);
  //echo  json_encode($datausuarios[0]);
  $arrayTitulo = [];
  $arrayTituloImprimir = "";
  $posT =0;
  foreach (  $Asignacion[0] as $key => $val){
    $arrayTitulo[$posT] = $key;
    $posT++;
  }  


  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion);
  return; 
}

private function Buscar3 ($Arr =array()){
  $Asignacion =array();
    $Asignacion= $this->ReporVentasModels->getReporVentasIdColum($Arr[0],urldecode($Arr[1]));
    $Asignacion2= $this->ReporteVentasModels2->getReporVentasIdColum($Arr[0],urldecode($Arr[1]));
    $Asignacion = array_merge($Asignacion, $Asignacion2);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion); 
}
private function Buscar4 ($Arr = array()){
  $Asignacion =array();
    $Asignacion= $this->ReporVentasModels->getReporVentasLimiteColum($Arr[0],$Arr[1],urldecode($Arr[2]));
    $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltroColumnas('s',urldecode($Arr[2]));
    $Asignacion = array_merge($Asignacion, $Asignacion2);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion); 
}
private function Buscar5 ($Arr =  array()){
  $Asignacion =array();
  $Asignacion = $this->ReporVentasModels->getReporVentasFiltroLimitesColumnas(urldecode($Arr[0]),$Arr[1],$Arr[2],urldecode($Arr[3]));
  $Asignacion2= $this->ReporteVentasModels2->getReporVentasFiltroColumnas(urldecode($Arr[0]),urldecode($Arr[3]));
  $Asignacion = array_merge($Asignacion, $Asignacion2);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion); 

}
private function MetaData(){
  $Asignacion =array();
  $Asignacion = $this->ReporVentasModels->MetaData();
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Asignacion); 
}



    protected function middleware()
    {
      return ['Sesion'];
    }

	
}