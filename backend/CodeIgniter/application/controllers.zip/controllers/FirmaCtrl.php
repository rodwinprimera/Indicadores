<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class FirmaCtrl extends MY_Controller {
    public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
      
  }
  public function _remap($met,$parametros = array()){

    $method = $_SERVER['REQUEST_METHOD'];

   if($met ==="index"){
  
    switch ($method)  
    { case 'PUT':
      break;
      case 'POST':
        $this->cargar_archivo();
      break;
      case 'GET': 
        $this->Firma($parametros);
      case 'HEAD': 
      break; 
      case 'DELETE':
      break; 
      case 'OPTIONS':
     break; 
     default: 
     echo json_encode( "Error" );
     break; 
    }
  }

  
  
   }

   private function Firma(){
 
    $Ruta = Raiz();
    if (Existe($Ruta.'/Firmas/') === false){
        CrearCarpeta($Ruta.'/Firmas/');
       }
       $Token = FALSE;
       $Header =  $this->input->request_headers();
       if(isset($Header['Authorization'])){
           $Authorization= $Header['Authorization'];
           if(  $Authorization !=""){
               $Authorization =str_replace('Bearer ','', $Authorization);
               $Token = ValidarToken($Authorization);
           }
       }
       if(isset($this->session)){
        $User =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
      }else{
        $User =  $Token== FALSE ? null:  $Token ;
      }
    
  
    //echo MI_HOST.'/Firmas/'.$User.'.png';
    header("Content-type: image/png");
    $cadena = "Mi firma";
    $im     = imagecreatefrompng($Ruta.'/Firmas/'.$User.'.png');
    $naranja = imagecolorallocate($im, 0, 210, 60);
    $px     = (imagesx($im) - 7.5 * strlen($cadena)) / 2;
    imagestring($im, 24, $px, 25, $cadena, $naranja);
    imagepng($im);
    imagedestroy($im);
    


}

function cargar_archivo() {
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if(isset($this->session)){
    $User =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
  }else{
    $User =  $Token== FALSE ? null:  $Token ;
  }
  
  $Datos = count($_POST) ===0 ? $this->input->raw_input_stream :  $this->input->post();
  if(is_string($Datos) ===true){
    $Datos =  json_decode($Datos, true);
  }
  $Ruta = Raiz();
  if (Existe($Ruta.'/Firmas/') === false){
      CrearCarpeta($Ruta.'/Firmas/');
     }

  $mi_archivo = $Datos['mi_archivo'];
  $data = base64_decode( $mi_archivo );
  file_put_contents($Ruta.'/Firmas/'.$User.".png", $data);
  echo json_encode(array("ok"=>"Se Proceso Con exito") ); 
  return;

}


protected function middleware()
{
  return ['Sesion','Permisos'];
}
}
