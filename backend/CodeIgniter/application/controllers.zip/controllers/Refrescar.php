<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Refrescar extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
   
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];

 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
    
    break;
    case 'POST': 
     
    break;
    case 'GET': 
      if(isset($this->session)){

        if( $this->session->userdata("User") != null ){
          @session_start();
          echo json_encode( array("ref"=>"refrescado" ));
      }else{
          echo json_encode( array("ref"=>"No hay Sesion" ));
      } 
      } else{
        echo json_encode( array("ref"=>"refrescado" ));
      }   
         
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
    
    break; 
    case 'OPTIONS': 
    
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }



    protected function middleware()
    {
      return ['Sesion'];
    }

	
}