<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PermisosCtrl extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
      $this->load->library('Pdf');
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];

 switch ($met)  
 { case 'Buscar1':
     $this->Buscar1($parametros); 
     break;
   case 'Buscar2': 
     $this->Buscar2($parametros);   
   break;
   case 'Buscar3': 
     $this->Buscar3($parametros); 
   break; 
   case 'Buscar4': 
    $this->Buscar4($parametros);
   break; 
   case 'Buscar5': 
    $this->Buscar5($parametros);
   break; 
   case "MetaData":
    $this->MetaData($parametros);
   break;
   case "Pdf":
    $this->Pdf();
    break;

 }
 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
      $this->Edit(); 
    break;
    case 'POST': 
      $this->Add();
    break;
    case 'GET': 
      $this->Search($parametros);
 break;
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
      $this->Delete($parametros); 
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }
private function Add(){
  $Datos = count($_POST) ===0 ? $this->input->raw_input_stream :  $this->input->post();
  if(is_string($Datos) ===true){
    $Datos =  json_decode($Datos, true);
  }

    $Permisoses= $this->PermisosModels->Add($Datos);

  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses);
}
     
private function Edit(){
  $Datos = $this->input->raw_input_stream;
  if(is_string($Datos) ===true){
    $Datos =  json_decode($Datos, true);
  }
  $Permisoses= $this->PermisosModels->Edit($Datos);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses);
    
}

private function Delete($ID ){
  $Permisoses= $this->PermisosModels->Delete($ID[0]);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses);
}

// aqui viene los metodos de buscar



private function Search($Arr =array() ){
  $Permisoses =array();
  switch (count($Arr)) 
  { case 0:
    $Permisoses= $this->PermisosModels->getPermisos();
    break;
    case 1: 
      $Permisoses = $this->PermisosModels->getPermisos($Arr[0]);
    break;
    case 2: 
      $Permisoses = $this->PermisosModels->getPermisosLimite($Arr[0],$Arr[1]);
    break; 
    case 4: 
      $Permisoses = $this->PermisosModels->getPermisosLimiteOrden($Arr[0],$Arr[1],$Arr[2],$Arr[3]);
    break; 
    case 5: 
      $Permisoses = $this->PermisosModels->getPermisosLimiteOrdenColumnas($Arr[0],$Arr[1],$Arr[2],$Arr[3],urldecode($Arr[4]));
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 
}

private function Buscar1 ($Arr = array()){
  $Permisoses =array();
  switch (count($Arr)) 
  {
    case 1: 
      $Permisoses = $this->PermisosModels->getPermisosFiltro(urldecode($Arr[0]));
    break;
    case 3: 
      $Permisoses = $this->PermisosModels->getPermisosFiltroLimite(urldecode($Arr[0]),$Arr[1],$Arr[2]);
    break; 
    case 5: 
      $Permisoses = $this->PermisosModels->getPermisosFiltroLimiteOrden(urldecode($Arr[0]),$Arr[1],$Arr[2],$Arr[3],$Arr[4]);
   break; 
   case 6: 
    $Permisoses = $this->PermisosModels->getPermisosFiltroLimiteOrdenColumnas(urldecode($Arr[0]),$Arr[1],$Arr[2],$Arr[3],$Arr[4],urldecode($Arr[5]));
    break; 
   default: 
   echo json_encode( $Arr );
   break; 
  }
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 
  
}
private function Buscar2 ($Arr =array()){
  $Permisoses =array();
  $Permisoses = $this->PermisosModels->getPermisosFiltroColumnas(urldecode($Arr[0]),urldecode($Arr[1]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 
}

private function Buscar3 ($Arr =array()){
  $Permisoses =array();
    $Permisoses= $this->PermisosModels->  getPermisosIdColum($Arr[0],urldecode($Arr[1]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 
}
private function Buscar4 ($Arr = array()){
  $Permisoses =array();
    $Permisoses= $this->PermisosModels->getPermisosLimiteColum($Arr[0],$Arr[1],urldecode($Arr[2]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 
}
private function Buscar5 ($Arr =  array()){
  $Permisoses =array();
  $Permisoses = $this->PermisosModels->getPermisosFiltroLimitesColumnas(urldecode($Arr[0]),$Arr[1],$Arr[2],urldecode($Arr[3]));
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 

}

private function Pdf(){

  $Permisoses= $this->PermisosModels->getPermisos();
  $Permisoses = str_replace('C\u00c3\u00b3digo','Codigo',json_encode($Permisoses));
  $Permisoses = str_replace('Tel\u00c3\u00a9fono','Telefono',$Permisoses);
  $Permisoses = str_replace('Direcci\u00c3\u00b3n','Direccion',$Permisoses);
  $Permisoses= json_decode($Permisoses);
 $bodytPermisoses= $this->BodyTabla($Permisoses,array('Codigo','Rut',"Nombre","Apellidos",'Telefono','Direccion',"Comuna"));
 //echo json_encode($Permisoses);
// return;
  $tcpdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
  $tcpdf->SetAuthor('segmarind');
  $tcpdf->SetTitle('Reporte de Permisoses');
  $tcpdf->SetSubject('segmarind');
  $tcpdf->SetKeywords('TCPDF, PDF, segmarind, test, guide');
  $tcpdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, "", "", array(0,65,256), array(0,65,127));
  $tcpdf->setFooterData(array(0,65,0), array(0,65,127));
  $tcpdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
  $tcpdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
  $tcpdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
  $tcpdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
  $tcpdf->SetHeaderMargin(PDF_MARGIN_HEADER);
  $tcpdf->SetFooterMargin(PDF_MARGIN_FOOTER);
  $tcpdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
  $tcpdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
if (@file_exists(dirname(__FILE__).'/lang/eng.php'))
{
// optional
require_once(dirname(__FILE__).'/lang/eng.php');
// optional
$tcpdf->setLanguageArray($l);
}
 
$tcpdf->setFontSubsetting(true);
$tcpdf->AddPage();
$set_html = <<<EOD
 
 

<h3  style="text-align: center;">Reporte De Permisoses</h3>

<br/>

<br>
<br/>
<br/>

<br>
<br>



<table   border="1" >

<tr>
<th ><FONT SIZE="8"><b> Código</b></FONT></th>
<th ><FONT SIZE="8"><b> Rut</b></FONT></th>
<th ><FONT SIZE="8"><b> Nombre</b></FONT></th>
<th ><FONT SIZE="8"><b> Apellidos </b></FONT></th>
<th ><FONT SIZE="8"><b> Teléfono</b></FONT></th>
<th ><FONT SIZE="8"><b> Dirección</b></FONT></th>
<th ><FONT SIZE="8"><b> Comuna</b></FONT></th>
</tr>
$bodytPermisoses
</table> 
EOD;
$tcpdf->writeHTMLCell(0, 0, '', '', $set_html, 0, 1, 0, true, '', true);
$tcpdf->Output('tcpdfexample-onlinecode.pdf', 'I');
  return;
}


function BodyTabla($arr,$Titulos){
 
  $Fi = "";
  foreach ($arr as $Fila){
    $Fi=  $Fi.'<tr>';
    $Colum= '';
 
    
         for( $i=0; $i< count($Titulos); $i++  ){
          foreach (  $Fila as $key => $val){
          if( $Titulos[$i] ===$key){
            $Colum =  $Colum. '<td ><FONT SIZE="8"> '. utf8_decode($val).' </FONT></td>';
          }
        }
        }
    
    $Fi= $Fi.$Colum.'</tr>';
  }
return $Fi;
}
private function MetaData(){
  $Permisoses =array();
  $Permisoses = $this->PermisosModels->MetaData();
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($Permisoses); 
}

    protected function middleware()
    {
      return ['Sesion','Permisos'];
    }

	
}