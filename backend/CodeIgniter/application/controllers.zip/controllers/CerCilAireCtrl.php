<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class CerCilAireCtrl extends MY_Controller {
function __construct() {
  
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header('content-type: application/json; charset=utf-8');
  $method = $_SERVER['REQUEST_METHOD'];
  if($method == "OPTIONS") {
      die();
  }
parent::__construct(); 
// add library of Pdf 
$this->load->library('Pdf');
}


public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];
  if($met ==="Alarma"){
  
    $this->Alarma();
   }

 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
     // $this->Edit(); 
    break;
    case 'POST': 
      //$this->Add();
    break;
    case 'GET': 
      $this->GestionCer($parametros);
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
     // $this->Delete($parametros); 
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }



private function Verificar($Nombre,$DB = ""){
  $Dir = Raiz();
  if (Existe($Dir.'/CerCilAire/'.$Nombre.'.pdf') === true){
     return $this->Verificar(Random($DB));
  }else{
    return $Nombre;
  }
 
}
public function Alarma(){
  
  $ArrayBalsasPorVencer = $this->AirCylinderModels->Alarma();
  
  foreach ($ArrayBalsasPorVencer as $Fila){
    $Usuario= $this->ClientModels->getClient($Fila->Armador);
    $Serial = $Fila->Serie;
    $DatosEditar = '{"0":"'. $Fila->ID.'", "12":"1"}';
    $DatosEditar =  json_decode($DatosEditar, true);
    $isn= $this->AirCylinderModels->Edit($DatosEditar);
  if($Usuario[0]->Correo != ""){
    $htmlContent = '<h1>Certificado de Cilindro De Aire</h1>';
    $htmlContent .="<p> Su Cilindro De Aire : $Serial, Esta Por VENCER actualmente tiene una vigencia de 30 dias.</p>";
    EmailHtml($Usuario[0]->Correo,"SEGMARIND ADVERTENCIA", $htmlContent);
  };
  }
  $ArrayBalsasVencidas = $this->AirCylinderModels->Alarma2();
  foreach ($ArrayBalsasVencidas as $Fila){
    $Usuario= $this->ClientModels->getClient($Fila->Armador);
    $DatosEditar = '{"0":"'. $Fila->ID.'","9":"Vencido", "12":"2"}';
      $DatosEditar =  json_decode($DatosEditar, true);
     
      $isn= $this->AirCylinderModels->Edit($DatosEditar);
    if($Usuario[0]->Correo != ""){
  
      $Serial = $Fila->Serie;
      $htmlContent = '<h1>Certificado De Aire </h1>';
      $htmlContent .="<p> Su Extintor: $Serial, Esta Vencidad actualmente deber renovar su Certificado .</p>";
      EmailHtml($Usuario[0]->Correo,"SEGMARIND ADVERTENCIA", $htmlContent);
   
      $this->MinutesModels->Edit($DatosEditar);
      
    };
    }

}
private function GetPremisos(){
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
  if(isset($this->session)){
    $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
 }else{
    $ID =   $Token== FALSE ? 0 :  $Token ;
 }
  $User = $this->UserModels->getUser($ID);
  $Nivel =$User[0]->Nivel;
  $Permiso= $this->db->get_where('detalleniveles',array("Status"=>"Activo","Ruta"=>"Inspetor","Nivel"=>$Nivel))->result();
  $per =0;
  if(  count($Permiso)>0){
  return $Permiso[0]->Permiso;
}else{
  return 0;
}

}


public function GestionCer($parametros)
{
  $FirmanteInterno="";
  $Nombre = "";
  $Dir = Raiz(); 
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
   //$User=  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
   if(isset($this->session)){
    $User =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
 }else{
     $User =   $Token== FALSE ? 0 :  $Token ;
  }

  if(count($parametros) ===0){ 
    echo "Debe enviar acta";
    return;
  } 
  if(DbMultiple== TRUE){ 
    $Nombre = $this->Verificar(Random($this->UserDB), $this->UserDB);
    
  }else{
    $Nombre = $this->Verificar(Random());
  }
 
  $CilAire = $this->AirCylinderModels->getAirCylinder($parametros[0]); 

    if( $CilAire != null  AND count($parametros) ===1){
      if($CilAire[0]->StatusCertificado === 'Activo'){
        header("Content-type: application/pdf");
        header("Content-Disposition: inline; filename=documento.pdf");
        readfile($Dir.'CerCilAire/'.$CilAire[0]->Certificado.'.pdf');
        return;
      }
      
  } 
  $Trabajo = json_decode($CilAire[0]->Trabajo, true);
  $Cliente= $this->ClientModels->getClient($CilAire[0]->Armador);

  $CodigoPlanilla =Digitos($CilAire[0]->ID,4);
  $Fecha= date("Y-m-d");
  $Vence = AddFechaActual(365);

  if(count($parametros) ===2){

    $TDatos =json_decode($CilAire[0]->Trabajo,true);
    $DatosEditar = '{"0":"'.$CilAire[0]->ID.'","11":"'.$Vence.'", "12":"0"}';
    $CilAire[0]->Vence = $Vence ;
    $DatosEditar =  json_decode($DatosEditar, true);
    $isn= $this->AirCylinderModels->Edit($DatosEditar);
    // Buscamos los datos del usuario
   $permiso= $this->GetPremisos();
  if($permiso == 1){
    $FirmanteInterno =  random_int(1, 5);;
  }
   
  
  if (Existe($Dir.'/Firmas/'.$FirmanteInterno .".png") === false){
    echo(json_encode(array("Error"=>"Firma no existe")));
    return ;
  }
// Verificamos quien firmara el documento segun si nivvel 
  if($permiso == 1){
    // ispector empresa
    $DatosEditar = '{"0":"'.$CilAire[0]->ID.'","8":"'.$User.'"}';
    $DatosEditar =  json_decode($DatosEditar, true);
      $isn= $this->AirCylinderModels->Edit($DatosEditar);
  
    
  }else{
    echo(json_encode(array("Error"=>"No autorizado")));
  }
 

  }else{
    // si no desea firmar documento igual preguntamos las firmas
  
    $FirmanteInterno = $CilAire[0]->Inspector == null ? 'Nada':$FirmanteInterno  ;
  }

 

  // verificamos si ya existe un documento creado y guardamos el nombre
  

 if ($CilAire[0]->Certificado != "" and Existe($Dir.'CerCilAire/'.$Nombre.'.pdf') AND count($parametros) ===1  ){
  // si existe el documento lo mandamos a mostrar
  // y como lo eliminamos previamente de querer crear la firma no hay problema
  header("Content-type: application/pdf");
  header("Content-Disposition: inline; filename=documento.pdf");
  readfile($Dir.'CerCilAire/'.$CilAire[0]->Certificado.'.pdf');
  return;
 }
// buscamos la informacion que llevara el Cer





$Year = date("Y");
$Armador= $Cliente[0]->Nombre.' '.  $Cliente[0]->Apellidos;
$Rut = $Cliente[0]->Rut;
$Lugar = $CilAire[0]->Lugar;
$NOTA = "Nota";
$trb= json_decode($CilAire[0]->Trabajo);

$Tabla =  json_encode($trb->Trabajo);



$Tabla = str_replace('Especificaci\u00f3n',utf8_encode('Especificación'),$Tabla);

 
$Tabla=json_decode($Tabla,true);
//$BodyElementos=  $this->BodyTabla( $Tabla);
$TablaImprimir = [];
foreach ($Tabla as $Key=> $val){
  $DatosA = [];
  
  $DatosA[utf8_encode('Serie Nº')]= $CilAire[0]->Serie;
  $Dat = "";
  foreach ($val as $Key2=> $val2){
    $DatosA[$val2['Titulo']]=$val2['value'];
    if($val2['value'] != ""){
      $Dat= $val2['value'];
    }
    //$TablaImprimir[$Key] = array($val2['Titulo'] => $val2['value'], );
  }
  if ($Dat != ''){
    $TablaImprimir[$Key] = $DatosA;
  }
 
}
$BodyElementos=  $this->BodyTabla( $TablaImprimir);


   



   




  
// coder for CodeIgniter TCPDF Integration
// make new advance pdf document
$tcpdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
 
// set document information

$tcpdf->SetAuthor('segmarind');
$tcpdf->SetTitle('Cettificado De Botella Equipo Respiracion Autonoma');
$tcpdf->SetSubject('segmarind');
$tcpdf->SetKeywords('TCPDF, PDF, segmarind, test, guide');
 
//set default header information
 
$tcpdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, "", "", array(0,65,256), array(0,65,127));


$tcpdf->setFooterData(array(0,65,0), array(0,65,127));
 
//set header  textual styles
$tcpdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//set footer textual styles
$tcpdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
 
//set default monospaced textual style
$tcpdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
 
// set default margins
$tcpdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
// Set Header Margin
$tcpdf->SetHeaderMargin(PDF_MARGIN_HEADER);
// Set Footer Margin
$tcpdf->SetFooterMargin(PDF_MARGIN_FOOTER);
 
// set auto for page breaks
$tcpdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image for scale factor
$tcpdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// it is optional :: set some language-dependent strings
if (@file_exists(dirname(__FILE__).'/lang/eng.php'))
{
// optional
require_once(dirname(__FILE__).'/lang/eng.php');
// optional
$tcpdf->setLanguageArray($l);
}
 
// set default font for subsetting mode
$tcpdf->setFontSubsetting(true);



// Set textual style
// dejavusans is an UTF-8 Unicode textual style, on the off chance that you just need to
// print standard ASCII roasts, you can utilize center text styles like
// helvetica or times to lessen record estimate.
//$tcpdf->SetFont('dejavusans', '', 14, '', true);
 
// Add a new page
// This technique has a few choices, check the source code documentation for more data.
$tcpdf->AddPage();
if($FirmanteInterno != "Nada"){
  $tcpdf->Image( $Dir.'/Firmas/'.$FirmanteInterno.".png", 130, 230, 60);
}

$style = array(
  'border' => 0,
  'vpadding' => 'auto',
  'hpadding' => 'auto',
  'fgcolor' => array(0,0,0),
  'bgcolor' => array(255,255,255),
  'module_width' => 1, // width of a single module in points
  'module_height' => 1 // height of a single module in points
);
$MI_HOST = $this->ConfigModels->Value('MI_HOST');
 $tcpdf->write2DBarcode($MI_HOST.'CodeIgniter/CerCilAire/'.$Nombre.'', 'QRCODE,Q', 90, 235, 30, 30, $style, 'C');
// set text shadow for effect
/*
$tcpdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,197,198), 'opacity'=>1, 'blend_mode'=>'Normal'));
 
//Set some substance to print
 */
$set_html = <<<EOD
 
 
<h3  style="text-align: center; text-decoration: underline;">CERTIFICADO DE INSPECCION DE BOTELLA 
EQUIPO RESPIRACION AUTONOMA
</h3>
<h4  style="text-align: center;">IEB  $CodigoPlanilla/$Year</h4>

<table border="1"   >

<tr>
<td  WIDTH= "33%" height = "50PX"  ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="11"><b>Nombre Armador</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="10"> $Armador</FONT></td>

<td  WIDTH= "33%" height = "50PX" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="11"><b>Rut</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="10"> $Rut</FONT></td>

<td  WIDTH= "33%" height = "50PX"><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="11"><b>Fecha</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="10"> $Fecha</FONT></td>
</tr>
<tr>
<td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="11"><b>NORMA</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="10"> D.S. (M) N° 752 año 1982
DGTM O A- 42/002 año 2006
</FONT></td>
<td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="11"><b>Lugar</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="10"> $Lugar</FONT></td>
<td  WIDTH= "33%" ><span style= "text-align: center; display:block;"><FONT style= "text-align: center; display:block;" SIZE="11"><b>Vencimiento</b> </FONT></span><br><FONT style= "text-align: center; display:block;" SIZE="10"> $Vence</FONT></td>
</tr>


</table>

<br/>
<br/>
<h5  style="text-align: justify; ">El abajo firmante, Inspector debidamente autorizado, certifica que el presente Cilindro de Aire, ha sido inspeccionado y mantenido de acuerdo a las especificaciones técnicas que les rige, D.S. (M) N° 752 año 1982 y su norma complementaria señalada en el Punto A, Circular DGTM O A- 42/002 del 6 de Junio del 2006.</h5>
<br/>

<br/>
<FONT style= "text-align: center; display:block;" SIZE="9"><b>IDENTIFICACION EQUIPO</b></FONT><br>
<table   border="1" >

$BodyElementos


</table>
<br/>
<br/>

<FONT SIZE="10" >NOTA: </FONT><br>

<br/>
<FONT SIZE="10" >IE	=	Inspección Externa</FONT><br>
<FONT SIZE="10" >II	= 	Inspección Interna</FONT><br>
<FONT SIZE="10" >PH	=	Prueba Hidrostática </FONT><br>
<FONT SIZE="10" >R  =	Recarga</FONT><br>


 
EOD;

//Print content utilizing writeHTMLCell()
$tcpdf->writeHTMLCell(0, 0, '', '', $set_html, 0, 1, 0, true, '', true);
$tcpdf->SetFont("", 'B', 10);



  $tcpdf->MultiCell(70,5, "____________________________
         Inspector Empresa
Resolución C.P. Chacabuco 12.265/399
 ", 0, 'C', 0, 1, 125, 235, true, 0, false, false, 40, 'M', false);

 $tcpdf->SetFont("", '', 8);
 $MI_HOST = $this->ConfigModels->Value('MI_HOST');
$tcpdf->MultiCell(175,5, "Puede verificar la valides de este documiento en: ".$MI_HOST."Sistema/Cer/CilAire Debe usar el Código: $Nombre ", 0, 'C', 0, 0, 10, 265, true, 0, false, false, 35, 'M', true);
$tcpdf->SetFont("", 'B', 10);

 switch (count($parametros)) { 
  
  case 0:
    break;
  case 1:
    $tcpdf->Output('Cer.pdf', 'I');
  break;
  case 2:
   if (Existe($Dir.'/CerCilAire/') === false){
    CrearCarpeta($Dir.'/CerCilAire/');
   
    
   }
   
    $tcpdf->Output($Dir.'/CerCilAire/'.$Nombre.'.pdf', 'F');
    if( $FirmanteInterno != 'Nada' ){
      //$DatosArmador aqui enviamos los datos del Cer
      // actualizamos la fecha de vencimiento  a un ano 
      $this->AirCylinderModels->GuardarActa($parametros[0],$Nombre);
    }
   
    
    header("Content-type: application/pdf");
    header("Content-Disposition: inline; filename=documento.pdf");
    readfile($Dir.'CerCilAire/'.$Nombre.'.pdf');
   
  
    return;
    
    break;
  }





//
// successfully created CodeIgniter TCPDF Integration
}

function BodyTabla($arr){
  
  $arrayTitulo = [];
  $arrayTituloImprimir = "";
  $posT =0;
  $arrayTituloImprimir ="<tr>";
  $Fi = "";
  foreach (  $arr[0] as $key => $val){
    $arrayTitulo[$posT] = $key;
   
      $arrayTituloImprimir=$arrayTituloImprimir.'<th ><FONT SIZE="8"><b>'.utf8_decode($key).'</b></FONT></th>';
   
    $posT++;
  }
  $arrayTituloImprimir =$arrayTituloImprimir."</tr>";
  foreach ($arr as $Fila){
    $Fi=  $Fi.'<tr>';
    $Colum= '';
 
    
         for( $i=0; $i< count($arrayTitulo); $i++  ){
          foreach (  $Fila as $key => $val){
          if( $arrayTitulo[$i] ===$key){
            $Colum =  $Colum. '<td ><FONT SIZE="8"> '. $val.' </FONT></td>';
          }
        }
        }
    
    $Fi= $Fi.$Colum.'</tr>';
  }
return $arrayTituloImprimir.$Fi;
}

protected function middleware()
{
  return ['Sesion','Permisos'];
}
}
/* end CerCilAireCtrl.php file for CodeIgniter TCPDF Integration */
?>