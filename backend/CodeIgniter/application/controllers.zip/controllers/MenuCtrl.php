<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MenuCtrl extends MY_Controller {
 
  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS,PATCH, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
      
      $this->Sucursales = $this->ConfigModels->Value("Sucursales");
      $this->Almacen = $this->ConfigModels->Value('Almacen');
      $this->Ventas = $this->ConfigModels->Value('Ventas');
      $this->Extintores = $this->ConfigModels->Value('Extintores');
      $this->Balsas = $this->ConfigModels->Value('Balsas');
      $this->Manguera = $this->ConfigModels->Value('Manguera');
      $this->TrajeDeInmercion = $this->ConfigModels->Value('TrajeDeInmercion');
      $this->BANCOCO2 = $this->ConfigModels->Value('BANCOCO2');
      $this->BANCOEX = $this->ConfigModels->Value('BANCOEX');
      $this->CilindroDeAire = $this->ConfigModels->Value('CilindroDeAire');
      $this->firma = $this->ConfigModels->Value('firma');
      $this->UseToken = $this->ConfigModels->Value('UseToken');
      $this->WOOR = $this->ConfigModels->Value("WOOR");;
  
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];


 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
     
    break;
    case 'POST': 
     
    break;
    case 'GET': 
    
      if(!isset($this->UserDB) && DbMultiple === true) {
         header('Content-type: application/json; charset=utf-8');
         echo json_encode(array()); 
         return  ;
         
      }
      $this->CrearMenu();
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
      
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }
 private function CrearMenu(){
   $Token = FALSE;
   $Header =  $this->input->request_headers();
   if(isset($Header['Authorization'])){
       $Authorization= $Header['Authorization'];
       if(  $Authorization !=""){
           $Authorization =str_replace('Bearer ','', $Authorization);
           $Token = ValidarToken($Authorization);
       }
   }
   if(isset($this->session)){
      $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
   }else{
      $ID =   $Token== FALSE ? null :  $Token ;
   }
   if ($ID == null){
      echo json_encode(array()); 
         return  ;
   }

    $User = $this->UserModels->getUser($ID);
    $Nivel =$User[0]->Nivel;
    $Permiso = $this->PermisosModels->getPermisosFiltro("sNivel^$Nivel");
    $MenuArray =  array();
    $menu = new stdClass();
    $menu->title= 'Cambio de Clave';
    $menu->url= '/Sistema/ChangePassword';
    $menu->Level=array(intval($Nivel));
    $menu->pos=32;
    $menu->Sub=false;
    $menu->ico='HttpsIcon';
    array_push($MenuArray, $menu );

 
    $menu = new stdClass();
    $menu->title= 'Home';
    $menu->url= '/Sistema';
    $menu->Level=array(intval($Nivel));
    $menu->ico='HomeIcon';
    $menu->pos=0;
    array_push($MenuArray, $menu );
    if( $this->BANCOCO2=== TRUE ||  $this->BANCOEX=== TRUE ||   $this->TrajeDeInmercion === TRUE  ){
      $menu = new stdClass();
      $menu->title= 'New Certificados';
      $menu->url= '/Sistema/CertGenerales';
      $menu->Level=array(intval($Nivel));
      $menu->ico='HttpsIcon';
      $menu->pos=36;
      array_push($MenuArray, $menu );
    }




    for ($i =0; $i < count($Permiso); $i++){
       if(  $this->Almacen === TRUE){
         if($Permiso[$i]->Ruta =='OrderSuppliers' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3   ){
            $menu = new stdClass();
            $menu->title= 'Pedidos';
            $menu->url= '/Sistema/OrderSuppliers';
            $menu->Level=array(intval($Nivel));
            $menu->ico='StoreIcon';
            $menu->pos=33;
            array_push($MenuArray, $menu );
            if( $this->WOOR == TRUE){
               $menu = new stdClass();
               $menu->title= 'Wordpress';
               $menu->url= '/Sistema/Wordpress';
               $menu->Level=array(intval($Nivel));
               $menu->ico='StoreIcon';
               $menu->pos=37;
               array_push($MenuArray, $menu );
            }
            
         }

       }
     
      
      
      if(  $this->Ventas === TRUE){
         if($Permiso[$i]->Ruta =='Ventas' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3   ){
            $menu = new stdClass();
            $menu->title= 'Ventas';
            $menu->url= '/Sistema/Ventas';
            $menu->Level=array(intval($Nivel));
            $menu->ico='StoreIcon';
            $menu->pos=29;
            array_push($MenuArray, $menu );
         }
         if($Permiso[$i]->Ruta =='AnularVenta' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3   ){
            $menu = new stdClass();
            $menu->title= 'Anular Venta';
            $menu->url= '/Sistema/AnularVenta';
            $menu->Level=array(intval($Nivel));
            $menu->ico='StoreIcon';
            $menu->pos=29;
            array_push($MenuArray, $menu );
         }
      }
      
      if($Permiso[$i]->Ruta =='Provider' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3   ){
         $menu = new stdClass();
         $menu->title= 'Proveedores';
         $menu->url= '/Sistema/Providers';
         $menu->Level=array(intval($Nivel));
         $menu->ico='StoreIcon';
         $menu->pos=30;
         array_push($MenuArray, $menu );
      }
      if(   $this->Almacen === TRUE){
         if($Permiso[$i]->Ruta =='Report' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3   ){
            $menu = new stdClass();
            $menu->title= 'Reportes';
            $menu->url= '/Sistema/Report';
            $menu->Level=array(intval($Nivel));
            $menu->ico='EqualizerIcon';
            $menu->pos=31;
            array_push($MenuArray, $menu );
         }

      }
      
      if (  $this->Sucursales === TRUE){
         if($Permiso[$i]->Ruta =='Store' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3   ){
            $menu = new stdClass();
            $menu->title= 'Tiendas';
            $menu->url= '/Sistema/Store';
            $menu->Level=array(intval($Nivel));
            $menu->ico='StoreIcon';
            $menu->pos=1;
            array_push($MenuArray, $menu );
         }

      }
     
     
     if($Permiso[$i]->Ruta =='Client' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Clientes';
        $menu->url= '/Sistema/Client';
        $menu->Level=array(intval($Nivel));
        $menu->ico='ContactsIcon';
        $menu->pos=2;
        array_push($MenuArray, $menu );
     }
     if(  $this->Almacen === TRUE){

     
     if($Permiso[$i]->Ruta =='Product' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Ingreso';
      $menu->url= '/Sistema/IngresoRapido';
      $menu->Level=array(intval($Nivel));
      $menu->ico='LocalMallIcon';
      $menu->Sub=true;
      $menu->pos=34;
      $menu->Superpos=6;
      array_push($MenuArray, $menu );
        $menu = new stdClass();
        $menu->title= 'Productos';
        $menu->url= '/Sistema/Product';
        $menu->Level=array(intval($Nivel));
        $menu->ico='LocalMallIcon';
        $menu->Sub=true;
        $menu->pos=3;
        $menu->Superpos=6;
        array_push($MenuArray, $menu );
     }
     if($Permiso[$i]->Ruta =='Classification' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Clasificación';
        $menu->url= '/Sistema/Classification';
        $menu->Level=array(intval($Nivel));
        $menu->ico='SortByAlphaIcon';
        $menu->pos=4;
        $menu->Sub=true;
        $menu->Superpos=6;
        array_push($MenuArray, $menu );
     }
     if($Permiso[$i]->Ruta =='Assignment' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Asignación';
        $menu->url= '/Sistema/Assignment';
        $menu->Level=array(intval($Nivel));
        $menu->ico='AssignmentIcon';
        $menu->pos=5;
        $menu->Superpos=6;
        $menu->Sub=true;
        array_push($MenuArray, $menu );
     }
     if($Permiso[$i]->Ruta =='Warehouse' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Almacén';
        $menu->url= '/Sistema/Warehouse';
        $menu->Level=array(intval($Nivel));
        $menu->ico='ApartmentIcon';
        $menu->pos=6;
        $menu->Super=true;
        array_push($MenuArray, $menu );
     }
     if($Permiso[$i]->Ruta =='Warehouse' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Gestión Almacén';
      $menu->url= '/Sistema/Warehouse';
      $menu->Level=array(intval($Nivel));
      $menu->ico='ApartmentIcon';
      $menu->pos=24;
      $menu->Sub=true;
      $menu->Superpos=6;
      array_push($MenuArray, $menu );
   }
}

   if ( $this->Balsas === TRUE){
      if($Permiso[$i]->Ruta =='Ship' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
         $menu = new stdClass();
         $menu->title= 'Embarcación';
         $menu->url= '/Sistema/Ship';
         $menu->Level=array(intval($Nivel));
         $menu->ico='DirectionsBoatIcon';
         $menu->pos=7;
         $menu->Sub=true;
         $menu->Superpos=8;
         array_push($MenuArray, $menu );
      }

  
    
     
     if($Permiso[$i]->Ruta =='Raft' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Balsa';
        $menu->url= '/Sistema/Raft';
        $menu->Level=array(intval($Nivel));
        $menu->ico='RowingIcon';
        $menu->pos=8;
        $menu->Super=true;
        $menu->Expan=true;
        array_push($MenuArray, $menu );
     }
     
     if($Permiso[$i]->Ruta =='Raft' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Balsas';
      $menu->url= '/Sistema/Raft';
      $menu->Level=array(intval($Nivel));
      $menu->ico='RowingIcon';
      $menu->pos=25;
      $menu->Superpos=8;
      $menu->Sub=true;
 
      array_push($MenuArray, $menu );
   }
   
     if($Permiso[$i]->Ruta =='Valve' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Válvula';
        $menu->url= '/Sistema/Valve';
        $menu->Level=array(intval($Nivel));
        $menu->ico='AddAlarmIcon';
        $menu->pos=10;
        $menu->Sub=true;
        $menu->Superpos=8;
        array_push($MenuArray, $menu );
     }
     if($Permiso[$i]->Ruta =='Order' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Orden De Trabajo';
      $menu->url= '/Sistema/Order';
      $menu->Level=array(intval($Nivel));
      $menu->ico='TripOriginIcon';
      $menu->pos=12;
      $menu->Sub=true;
      $menu->Superpos=8;
      array_push($MenuArray, $menu );
   }
   if($Permiso[$i]->Ruta =='Minutes' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Procesar Ordenes';
      $menu->url= '/Sistema/Process';
      $menu->Level=array(intval($Nivel));
      $menu->ico='CheckCircleIcon';
      $menu->pos=13;
      $menu->Sub=true;
      $menu->Superpos=8;
      array_push($MenuArray, $menu );
   }
   if($Permiso[$i]->Ruta =='Cylinder' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Cilindros De Inflado';
      $menu->url= '/Sistema/Cylinder';
      $menu->Level=array(intval($Nivel));
      $menu->ico='BatteryAlertIcon';
      $menu->pos=11;
      $menu->Sub=true;
      $menu->Superpos=8;
      array_push($MenuArray, $menu );
   }
   } 
     
    
    
    if(  $this->Extintores === TRUE ){

      if($Permiso[$i]->Ruta =='Extinguisher' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
         $menu = new stdClass();
         $menu->title= 'Extintor';
         $menu->url= '/Sistema/Extinguisher';
         $menu->Level=array(intval($Nivel));
         $menu->ico='BatteryStdIcon';
         $menu->pos=14;
         $menu->Super=true;
         $menu->Expan=true;
         array_push($MenuArray, $menu );
      }
      if($Permiso[$i]->Ruta =='Extinguisher' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
         $menu = new stdClass();
         $menu->title= 'Extintores';
         $menu->url= '/Sistema/Extinguisher';
         $menu->Level=array(intval($Nivel));
         $menu->ico='BatteryStdIcon';
         $menu->pos=26;
         $menu->Sub=true;
         $menu->Superpos=14;
         array_push($MenuArray, $menu );
      }
      if($Permiso[$i]->Ruta =='OrdenExtintor' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
         $menu = new stdClass();
         $menu->title= 'Orden De Trabajo Extintor';
         $menu->url= '/Sistema/OrderExtinguisher';
         $menu->Level=array(intval($Nivel));
         $menu->ico='HttpsIcon';
         $menu->pos=22;
         $menu->Sub=true;
         $menu->Superpos=14;
         array_push($MenuArray, $menu );
         
      }
    }
    
    
 if(  $this->CilindroDeAire=== TRUE){
   if($Permiso[$i]->Ruta =='AirCylinder' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Cilindros De Aire';
      $menu->url= '/Sistema/AirCylinder';
      $menu->Level=array(intval($Nivel));
      $menu->ico='BatteryStdIcon';
      $menu->pos=15;
      array_push($MenuArray, $menu );
   }

 }


 if(  $this->BANCOCO2=== TRUE){
   if($Permiso[$i]->Ruta =='BancoC02' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Banco DE CO2';
      $menu->url= '/Sistema/OrdenCo2';
      $menu->Level=array(intval($Nivel));
      $menu->ico='BatteryStdIcon';
      $menu->pos=33;
      array_push($MenuArray, $menu );
   }

 }
 if( $this->BANCOEX=== TRUE){
   if($Permiso[$i]->Ruta =='BancoEx' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'BANCO EXTINCIÓN INCENDIO';
      $menu->url= '/Sistema/OrdenBEI';
      $menu->Level=array(intval($Nivel));
      $menu->ico='BatteryStdIcon';
      $menu->pos=33;
      array_push($MenuArray, $menu );
   }

 }
    
     if(  $this->TrajeDeInmercion === TRUE){
      if($Permiso[$i]->Ruta =='CertificadoTraje' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
         $menu = new stdClass();
         $menu->title= 'Traje De inmersión';
         $menu->url= '/Sistema/ImmersionSuit';
         $menu->Level=array(intval($Nivel));
         $menu->ico='PoolIcon';
         $menu->pos=33;
         array_push($MenuArray, $menu );
      }
    
     }
     
     if($Permiso[$i]->Ruta =='User' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
        $menu = new stdClass();
        $menu->title= 'Usuario';
        $menu->url= '/Sistema/User';
        $menu->Level=array(intval($Nivel));
        $menu->ico='PersonIcon';
        $menu->pos=18;
        $menu->Super=true;
        $menu->Expan=true;
        array_push($MenuArray, $menu );
     }
     if($Permiso[$i]->Ruta =='User' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Usuarios';
      $menu->url= '/Sistema/User';
      $menu->Level=array(intval($Nivel));
      $menu->ico='PersonIcon';
      $menu->pos=27;
      $menu->Superpos=18;
      $menu->Sub=true;
      
      array_push($MenuArray, $menu );
   }
if(   $this->firma === TRUE){
   if($Permiso[$i]->Ruta =='Firma' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
      $menu = new stdClass();
      $menu->title= 'Firmas';
      $menu->url= '/Sistema/Firmas';
      $menu->Level=array(intval($Nivel));
      $menu->ico='HttpsIcon';
      $menu->pos=20;
      $menu->Sub=true;
      $menu->Superpos=18;
      array_push($MenuArray, $menu );
      
   }

}
     
     
   
     if ( $this->Manguera === TRUE){
      if($Permiso[$i]->Ruta =='HydraulicHose' AND $Permiso[$i]->Permiso != 6 AND $Permiso[$i]->Permiso != 3){
         $menu = new stdClass();
         $menu->title= 'Orden Manguera Hidráulica';
         $menu->url= '/Sistema/HydraulicHose';
         $menu->Level=array(intval($Nivel));
         $menu->ico='HttpsIcon';
         $menu->pos=23;
        
         array_push($MenuArray, $menu );
         
      }

     }
  
   
   
     
    }
    if(   $this->Balsas === TRUE){
      $menu = new stdClass();
      $menu->title= 'Certificados';
      $menu->url= '/Sistema/ListCertificate';
      $menu->Level=array(intval($Nivel));
      $menu->ico='HttpsIcon';
      $menu->pos=35;
     
      array_push($MenuArray, $menu );

    }


    if ( $this->Extintores === TRUE ){
      $menu = new stdClass();
      $menu->title= 'Certificado De Extintores';
      $menu->url= '/Sistema/CertExtinguisher';
      $menu->Level=array(intval($Nivel));
      $menu->ico='HttpsIcon';
      $menu->pos=35;
     
      array_push($MenuArray, $menu );
    }
   
    
    for( $i=0; $i< count($MenuArray); $i++  ){
        
        for( $j=$i+1; $j< count($MenuArray); $j++  ){
         if ($MenuArray[$i]->pos > $MenuArray[$j]->pos){
            $Aux = $MenuArray[$i];
            $MenuArray[$i]= $MenuArray[$j];
            $MenuArray[$j] = $Aux;
         }
        }
    }
    header('Content-type: application/json; charset=utf-8');
    echo json_encode($MenuArray); 
 }


function BodyTabla($arr,$Titulos){
 
  $Fi = "";
  foreach ($arr as $Fila){
    $Fi=  $Fi.'<tr>';
    $Colum= '';
 
    
         for( $i=0; $i< count($Titulos); $i++  ){
          foreach (  $Fila as $key => $val){
          if( $Titulos[$i] ===$key){
            $Colum =  $Colum. '<td ><FONT SIZE="8"> '. utf8_decode($val).' </FONT></td>';
          }
        }
        }
    
    $Fi= $Fi.$Colum.'</tr>';
  }
return $Fi;
}
protected function middleware()
    {
      return ["VerificacionDB"];
    }

	
}