<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ejemplo extends MY_Controller {
  
    
    public function index(){
      // $pass= password_hash('1234',PASSWORD_DEFAULT,array("cost"=>12));
      //  print_r($pass);

       // print_r($this->EjemploModelo->ejemplo2());
       print_r(GenerarToken(10));
    }
   
    
}