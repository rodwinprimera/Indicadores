<?php class BuscarCertificados extends MY_Controller { 
    
    function __construct() {
      
      
    parent::__construct(); 
    // add library of Pdf 
    $this->load->library('Pdf');
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    }
    
    
    public function _remap($met,$parametros = array()){
    
      $method = $_SERVER['REQUEST_METHOD'];
   
     if($met ==="index"){
    
      switch ($method)  
      { case 'PUT':
         // $this->Edit(); 
        break;
        case 'POST': 
          //$this->Add();
        break;
        case 'GET': 
          
          $this->GestionCertificado($parametros);
        case 'HEAD': 
          // echo json_encode( $method );
        break; 
        case 'DELETE': 
         // $this->Delete($parametros); 
        break; 
        case 'OPTIONS': 
         // echo json_encode( $method );
       break; 
       default: 
       echo json_encode( "Error" );
       break; 
      }
    }
    
    
     }
    
    
    
 

    
    public function GestionCertificado($parametros)
    {
        $OrdenesG = $this->OrdenesGModels->getOrdenesGFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0].'|11^2',1,0,0,"1",'s0|1|2|3|4|5|6|7|8|9|10|11|12');
        if(count($OrdenesG)<1){
          $OrdenesG = $this->OrdenesGModels->getOrdenesGFiltroLimiteOrdenColumnas('sCertificado^'.$parametros[0].'|11^5',1,0,0,"1",'s0|1|2|3|4|5|6|7|8|9|10|11|12');
          if(count($OrdenesG)<1){
            echo "Certificado No encontrado";
            return;
          }
            
        }
      $Dir = Raiz();

      $Token = FALSE;
      $Header =  $this->input->request_headers();
      if(isset($Header['Authorization'])){
          $Authorization= $Header['Authorization'];
          if(  $Authorization !=""){
              $Authorization =str_replace('Bearer ','', $Authorization);
              $Token = ValidarToken($Authorization);
          }
      }
      if ( $Token === FALSE ){
        $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
      
       
        $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
        $Token  =$DatosGET!=''?$DatosGET: $Token ;
        
       }
       if(isset($this->session)){
        $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
     }else{
        $ID =   $Token== FALSE ? null :  $Token ;
     }

       $DatosGET ="";
       if ($ID === null && $Token === FALSE ){
        $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
        $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
       }
      if( $ID != null OR  $DatosGET !=""){ 
            header("Content-type: application/pdf");
            header("Content-Disposition: inline; filename=documento.pdf");
            readfile($Dir.'CertificadosGenerales/'.$OrdenesG[0]->Certificado.'.pdf');
            return;
    }

    $DatosArmador  = $this->ClientModels->getClient($OrdenesG[0]->Armador);
    $Armador =  $DatosArmador[0]->Nombre.' '. $DatosArmador[0]->Apellidos;
    $CodigoPlanilla =Digitos($OrdenesG[0]->ID,4);
  

    $Fecha=$OrdenesG[0]->Fecha;
    $Vence = $OrdenesG[0]->Vence;
    $Email =  $DatosArmador[0]->Correo;
     $FechaI = $Fecha;
     $Fecha = $Vence;
     $Year = date("Y");
     $Embarcacion = $OrdenesG[0]->Lugar_Buque;
     $Bandera =$OrdenesG[0]->Bandera;
     $Lugar = $OrdenesG[0]->Lugar;
     $NOTA = "Nota";
     $Obs = $OrdenesG[0]->Observacion;
     if($Obs != ""){
      $Obs  = str_replace("\n", '<FONT/><FONT style= " display:block;" SIZE="3"><br>', $Obs);
      $Obs = ' <FONT SIZE="3"> Observaciones: <FONT/>  <FONT style= " display:block;" SIZE="3"><br>'.$Obs . '<FONT/>';
    }
     $Detalle =   json_decode(utf8_encode($OrdenesG[0]->Elementos), true); 
     if(count($Detalle)===0)return;
   
     $BodyElementos=  $this->BodyTabla($Detalle ); 
$data = array(
    'Embarcacion'=>  $Embarcacion,
    'Armador'=> $Armador,
    'Codigo'=>  $CodigoPlanilla,
    'Year' =>  $Year,
    'tabla'=>  $BodyElementos,
    'Bandera' => $Bandera,
    'Vence' =>  $Vence,
    "Fecha" => $Fecha,
    "Obs" =>   $Obs,
    "Lugar"=> $Lugar
);
    if($OrdenesG[0]->Tipo == 1){

 
        $this->load->view('header');
        $this->load->view('CertificadoCO2',$data);
        $this->load->view('footer');
        return;
      }
      if($OrdenesG[0]->Tipo == 2){

 
        $this->load->view('header');
        $this->load->view('CertificadoTraje',$data);
        $this->load->view('footer');
        return;
      }

      if($OrdenesG[0]->Tipo == 3){

 
        $this->load->view('header');
        $this->load->view('CertificadoBEI',$data);
        $this->load->view('footer');
        return;
      }
       
    }
    
    function BodyTabla($arr){
  
      $arrayTitulo = [];
      $arrayTituloImprimir = "";
      $posT =0;
      $arrayTituloImprimir ="<tr>";
      $Fi = "";
      foreach (  $arr[0] as $key => $val){
        $arrayTitulo[$posT] = $key;
        if($key=='Si' OR $key== 'No'){
          $arrayTituloImprimir=$arrayTituloImprimir.'<th  ><FONT SIZE="3"><b>'.utf8_decode($key).'</b></FONT></th>';
          
        }else{
          $arrayTituloImprimir=$arrayTituloImprimir.'<th ><FONT SIZE="3"><b>'.utf8_decode($key).'</b></FONT></th>';
        }
       
        $posT++;
      }
      $arrayTituloImprimir =$arrayTituloImprimir."</tr>";
      foreach ($arr as $Fila){
        $Fi=  $Fi.'<tr>';
        $Colum= '';
     
        
             for( $i=0; $i< count($arrayTitulo); $i++  ){
              foreach (  $Fila as $key => $val){
              if( $arrayTitulo[$i] ===$key){
                $Colum =  $Colum. '<td ><FONT SIZE="3"> '. $val.' </FONT></td>';
              }
            }
            }
        
        $Fi= $Fi.$Colum.'</tr>';
      }
    return $arrayTituloImprimir.$Fi;
    }
    
    protected function middleware()
    {
      return ["VerificacionDB"];
    }
    }
    /* end CertificadoBalsaCtrl.php file for CodeIgniter TCPDF Integration */
    ?>