<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class AnularVentaCrtl extends MY_Controller {

    public function __construct($config = 'rest')
    {
      header('Access-Control-Allow-Origin: *');
      header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
      header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
      header("Allow: GET, POST, OPTIONS, PUT, DELETE");
      header('content-type: application/json; charset=utf-8');
      $method = $_SERVER['REQUEST_METHOD'];
      if($method == "OPTIONS") {
          die();
      }
        parent::__construct();
    }
    public function _remap($met,$parametros = array()){

        $method = $_SERVER['REQUEST_METHOD'];
      

       if($met ==="index"){
      
        switch ($method)  
        { case 'POST': 
            
          break;
          case 'GET': 
            $this->Anular($parametros);
            break; 
          case 'HEAD': 
            // echo json_encode( $method );
          break; 
          case 'DELETE': 
           
          break; 
          case 'OPTIONS': 
           // echo json_encode( $method );
         break; 
         default: 
         echo json_encode( "Error" );
         break; 
        }
      }
      
      
       }
       private function Anular($ar){
           
           $DatosFactura = $this->VentasModels->getVentas($ar[0]);
           if ( count( $DatosFactura)=== 0 ){
            echo json_encode("Venta No Encontrada"); 
               return;
           }else{
               if($DatosFactura[0]->Status ==="Anulado"){
                echo json_encode("Venta Anulada"); 
                return;
               }
           }
           $DetalleVenta = $this->DetalleVentasModels->getDetalleVentasFiltro("s1^".$ar[0]);
          
           foreach ($DetalleVenta  as $key => $val){
               $Fecha = "";
               $Proveedor ='';
               $Precio = "";
               $Costo = "";

             if(  $val->DetalleM != null and  $val->DetalleM >0   ){
                $DetalleMov  = $this->ReporWareDetalleModels->getReporWareDetalle( $val->DetalleM);
                if (count($DetalleMov)>0){
                  if($DetalleMov[0]->Vence != ""){
                    $Fecha = $DetalleMov[0]->Vence;
                }
                $Proveedor =  $DetalleMov[0]->CodigoProve;
               $Precio =  $DetalleMov[0]->Precio;
                $Costo =  $DetalleMov[0]->Costo;

                }
                
             }
             if($Fecha != ""){
              $Producto = '{"Status":0,"Observacion":"Anular Venta","Cantidad":"'.$val->cantidad.'","CodigoProve":"'.$Proveedor.'","Costo":"'.$Costo.'","Precio":"'. $Precio.'","CodigoMo":"'.$val->Producto.'","Vencimiento": "'. $Fecha.'" }';
               
                $Producto= json_decode($Producto, true);
             }else{

                $Producto = '{"Status":0,"Observacion":"Anular Venta","Cantidad":"'.$val->cantidad.'","CodigoProve":"'.$Proveedor.'","Costo":"'.$Costo.'","Precio":"'. $Precio.'","CodigoMo":"'.$val->Producto.'","Vencimiento": "'."".'" }';
                $Producto= json_decode($Producto, true);
             }
             if($Proveedor == "" ){
            $Producto['CodigoProve'] = null;
             }

           $Producto= $this->WarehouseModels->Add($Producto);
           }
          $DatosFactura = $this->VentasModels->Delete($ar[0]);
          echo json_encode($Producto); 

       }

    protected function middleware()
    {
      return ['Sesion'];
    }

}