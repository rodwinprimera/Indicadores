<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class CertificadoBalsaCtrl extends MY_Controller { 
  private $AuMaritimo = false;
function __construct() {
  
  header('Access-Control-Allow-Origin: *');
  header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
  header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
  header("Allow: GET, POST, OPTIONS, PUT, DELETE");
  header('content-type: application/json; charset=utf-8');
  $method = $_SERVER['REQUEST_METHOD'];
  if($method == "OPTIONS") {
      die();
  }
parent::__construct(); 
// add library of Pdf 
$this->load->library('Pdf');
}


public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];
 if($met ==="Alarma"){
   
  $this->Alarma();
 }

 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
     // $this->Edit(); 
    break;
    case 'POST': 
      //$this->Add();
    break;
    case 'GET': 
      $this->GestionCertificado($parametros);
    case 'HEAD': 
      // echo json_encode( $method );
    break; 
    case 'DELETE': 
     // $this->Delete($parametros); 
    break; 
    case 'OPTIONS': 
     // echo json_encode( $method );
   break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }



private function Verificar($Nombre,$DB = ""){
  $Dir = Raiz();
  if (Existe($Dir.'/certificadobalsas/'.$Nombre.'.pdf') === true){
     return $this->Verificar(Random($DB));
  }else{
    return $Nombre;
  }
 
}

public function Alarma(){
  $ArrayBalsasPorVencer = $this->AlarmaBalsasModels->getAlarmaBalsas();
  
  if(count($ArrayBalsasPorVencer)>0){
    foreach ($ArrayBalsasPorVencer as $Fila){
      if($Fila->Correo != ""){
    
        $DatosEditar = '{"0":"'. $Fila->ID.'", "15":"1"}';
        $DatosEditar =  json_decode($DatosEditar, true);
        $isn= $this->RaftModels->Edit($DatosEditar);
        $htmlContent = '<h1>Certificado De Balsa Salvavidas</h1>';
        $htmlContent .="<p> Su Certificado de Balsa: $Fila->Serial, Esta Por VENCER actualmente tiene una vigencia de 30 dias.</p>";
        EmailHtml($Fila->Correo,"SEGMARIND ADVERTENCIA", $htmlContent);
      };
      }
  }
  
  $ArrayBalsasVencidas = $this->AlarmaBalsasModels->getAlarmaBalsas2();
 
  if(count($ArrayBalsasVencidas)>0){
    foreach ($ArrayBalsasVencidas as $Fila){
      if($Fila->Correo != ""){
    
        $DatosEditar = '{"0":"'. $Fila->ID.'","13":"Vencido", "15":"2"}';
        $DatosEditar =  json_decode($DatosEditar, true);
       
        $isn= $this->RaftModels->Edit($DatosEditar);
          
        $htmlContent = '<h1>Certificado De Balsa Salvavidas</h1>';
        $htmlContent .="<p> Su Balsa:$Fila->Serial, Esta Vencidad actualmente deber renovar su certificado de inspeccion.</p>";
        EmailHtml($Fila->Correo,"SEGMARIND ADVERTENCIA", $htmlContent);
        $Cert = $Fila->Certificado;
        $Acta = $this->MinutesFModels->getMinutesFFiltro("sCertificado^$Cert");
        $DatosEditar = '{"0":"'.$Acta[0]->ID.'","11":"Vencido"}';
        $DatosEditar =  json_decode($DatosEditar, true);
        $this->MinutesModels->Edit($DatosEditar);
        
      };
      }

  }

 

}

private function GetPremisos(){
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
   
   if(isset($this->session)){
    $ID =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
 }else{
    $ID =   $Token== FALSE ? null :  $Token ;
 }
  $User = $this->UserModels->getUser($ID);
  $Nivel =$User[0]->Nivel;
  $Permiso= $this->db->get_where('detalleniveles',array("Status"=>"Activo","Ruta"=>"Inspetor","Nivel"=>$Nivel))->result();
  $per =0;
  if(  count($Permiso)>0){
  return $Permiso[0]->Permiso;
}else{
  return 0;
}

}


public function GestionCertificado($parametros)
{
  $FirmanteInterno ="";
  if(DbMultiple== TRUE){ 
    $Nombre = $this->Verificar(Random($this->UserDB), $this->UserDB);
    
  }else{
    $Nombre = $this->Verificar(Random());
  }

  $Dir = Raiz(); // Obtenemos directorio raiz
  $Token = FALSE;
  $Header =  $this->input->request_headers();
  if(isset($Header['Authorization'])){
      $Authorization= $Header['Authorization'];
      if(  $Authorization !=""){
          $Authorization =str_replace('Bearer ','', $Authorization);
          $Token = ValidarToken($Authorization);
      }
  }
  if ( $Token === FALSE ){
    $DatosGET= isset($_GET["x"]) ? $_GET["x"]: "" ;
  
   
    $DatosGET =  $DatosGET!=""?ValidarToken($DatosGET) :"";
    $Token  =$DatosGET!=''?$DatosGET: $Token ;
    
   }
   
   if(isset($this->session)){
    $User =  $Token== FALSE ? $this->session->userdata("User") :  $Token ;
 }else{
     $User =  $Token== FALSE ? null :  $Token ;
 }
 
  if(count($parametros) ===0){ // validamos si la pteticion tiene el id del acta
    echo "Debe enviar acta";
    return;
  } 
  
  $Minuteses = $this->MinutesModels->getMinutes($parametros[0]); // Buscamos el acta 
  $CodigoPlanilla =Digitos($parametros[0],4);
  // verificamos si el acta esta finalizada o activa de estar finalizada mandamos a llamar el pdf
  if(  $Minuteses == null){
    $Minuteses = $this->MinutesFModels->getMinutesF($parametros[0]); 
    if( $Minuteses == null){
   
      echo(json_encode(array("Error"=>"Certificado no existe")));
      return;
     }else{
      if ($Minuteses->Tipo !=2){
        echo(json_encode(array("Error"=>"Envie Acta")));
        return;
      } 
     

      header("Content-type: application/pdf");
      header("Content-Disposition: inline; filename=documento.pdf");
      readfile($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf');
      return;
     }
  } 
  // verificamos si es tipo 2 el acta de lo contraio salimos del procedimeinto
  if ($Minuteses->Tipo !=2){
    echo(json_encode(array("Error"=>"Envie Acta")));
    return;
  } 

  // Si recibimos 2 parametros es indicativo de que el usuario quiere firmar el documento
  if(count($parametros) ===2){
    // modificamos la fecha de inspeccion a la fecha actual 
    $Fecha= date("Y-m-d");
    $Vence = AddFechaActual(365);
    $DatosEditar = '{"0":"'.$Minuteses->ID.'","7":"'.$Fecha.'","8":"'.$Vence.'" }';
    $Minuteses->FechaI = $Fecha;
    $Minuteses->FechaV = $Vence ;
    $DatosEditar =  json_decode($DatosEditar, true);
    $isn= $this->MinutesModels->Edit($DatosEditar);
    // Buscamos los datos del usuario
    $permiso= $this->GetPremisos();
  if($permiso == 1){
    $FirmanteInterno =  random_int(1, 5);
    $FirmanteMaritima = "";
  }else{
    $FirmanteInterno = "";
    if($permiso == 2){
      $FirmanteMaritima =  $User;
    }else{
      echo(json_encode(array("Error"=>"No permitido")));
      return ;
    }
  }
  // si no hya firma cargada mandamos error de firma no existe
  if (Existe($Dir.'/Firmas/'. $FirmanteInterno.".png") === false){
    echo(json_encode(array("Error"=>"Firma no existe")));
    return ;
  }
// Verificamos quien firmara el documento segun si nivvel 
  if($permiso == 1){
    // ispector empresa
    $DatosEditar = '{"0":"'.$Minuteses->ID.'","5":"'.$User.'"}';
    $DatosEditar =  json_decode($DatosEditar, true);

    if($Minuteses->Inspector_Empresa == null){
      // si no existe firma del ispector y existe un documento lo eliminamos para crear uno de nuevo 
      $isn= $this->MinutesModels->Edit($DatosEditar);
      if(Existe($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf')=== true){
        unlink($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf');
      }
    }else{
      // de existir firma es por que ya el documento fue firmado por un inspector
      echo(json_encode(array("Error"=>"Documento Firmado")));
      return;
    }
    // verificamos si el documento ya tiene una firma de la autoridad maritima
    $FirmanteMaritima = $Minuteses->Inspector_Autoridad_Maritima == null ? 'Nada':$Minuteses->Inspector_Autoridad_Maritima;
  }else{
  // semejante pero con inspector de la autoridad maritima
  if ($this->AuMaritimo === false)
  {
   echo(json_encode(array("Error"=>"Firma No Habilitada")));
  }
    if($Minuteses->Inspector_Autoridad_Maritima == null){
      $DatosEditar = '{"0":"'.$Minuteses->ID.'","4":"'.$User.'"}';
      $DatosEditar =  json_decode($DatosEditar, true);
      $isn= $this->MinutesModels->Edit($DatosEditar);
      if(Existe($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf')=== true){
        unlink($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf');
      }
    }else{
      echo(json_encode(array("Error"=>"Documento Firmado")));
      return;
    }
    $FirmanteInterno = $Minuteses->Inspector_Empresa == null ? 'Nada': $FirmanteInterno ;
  }
 

  }else{
    // si no desea firmar documento igual preguntamos las firmas
    $FirmanteMaritima = $Minuteses->Inspector_Autoridad_Maritima == null ? 'Nada':$Minuteses->Inspector_Autoridad_Maritima;
    $FirmanteInterno = $Minuteses->Inspector_Empresa == null ? 'Nada': $FirmanteInterno ;
  }



  // verificamos si ya existe un documento creado y guardamos el nombre
  $Nombre = $Minuteses->Certificado != ""? $Minuteses->Certificado :$Nombre;
 if ($Minuteses->Certificado != "" and Existe($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf') ){
  // si existe el documento lo mandamos a mostrar
  // y como lo eliminamos previamente de querer crear la firma no hay problema
  header("Content-type: application/pdf");
  header("Content-Disposition: inline; filename=documento.pdf");
  readfile($Dir.'certificadobalsas/'.$Minuteses->Certificado.'.pdf');
  return;
 }
 
// buscamos la informacion que llevara el certificado
 $Orden = $this->ReporDetalleOrdenModels->getReporDetalleOrden($Minuteses->Detalle);

$Hola =json_decode((utf8_encode(json_encode($Orden[0]))),true);
$CodigoDetalle= $Hola[utf8_encode('Código')];
$CodigoOrden= $Hola[utf8_encode('Orden')];

 $DatosArmador  = $this->ClientModels->getClient($Orden[0]->Armador);
  $Embarcacion = $Orden[0]->Embarcacion;
  $Armador =  $Orden[0]->Armador.' '. $Orden[0]->Apellido;
  $Capacidad = $Orden[0]->Capacidad;
  $Serial = $Orden[0]->Balsa;
  $CerAnt = $Minuteses->CertificadoA;
  $Marca = $Orden[0]->Marca;
  $Email =  $Orden[0]->Email;
  $FechaI = $Minuteses->FechaI;
  $Fecha = $Minuteses->Fecha;
  $FechaV = $Minuteses->FechaV;
   $ArrayORden = array('Serial','Tara','CO2','N2','Peso','ULTIMOPH' );
  $BodyCilindros=  $this->BodyTabla($Minuteses->CILINDROS, $ArrayORden); 
  $ArrayProduc = array('Nombre','Cantidad','Vence','Observacion');
  $Observacion = $Minuteses->observacion;
  $Arreglo = [];
  $ListaProd =  array('BENGALAS DE MANO','COHETES PARACAIDAS','BOMBA DE HUMO','RACIÓN DE ALIMENTO','RACIÓN DE AGUA','BOTIQUÍN','PASTILLAS PARA MAREO','BATERIA SALVAVIDA','PILAS LINTERNA','KIT DE REPARACIONES');
   
  foreach ( $Minuteses->ELEMENTOS as $val){
    
      if($val->Cantidad >= 0 AND $this->BuscarDentro($ListaProd,$val->Nombre) === true ){
        array_push($Arreglo,$val );
      }
   
       
  }



  $ActaA = "";
  $ActaA = $this->MinutesModels->getMinutes($Orden[0]->Acta);

  if(is_null($ActaA)){
    $ActaA = $this->MinutesFModels->getMinutesF($Orden[0]->Acta); 
  }
  $Arreglo2 = [];

  foreach ( $ActaA->ELEMENTOS as $val){
      if($val->Cantidad >= 0){
        $AuxPo = false;
        foreach ( $Arreglo as $val2){
     
         if($val2->Producto === $val->Producto ){
           if( $val->Cantidad >0 AND $val2->Cantidad > 0){
           if (ExistePalabra("Reemplazo",$val->Observacion) === true || ExistePalabra("Remplazo",$val->Observacion)=== true || ExistePalabra("reemplazar",$val->Observacion)=== true || ExistePalabra("remplazar",$val->Observacion)=== true ){
             if( BuscarNum($val->Observacion) >0){
              $val2->Cantidad =  $val2->Cantidad + ($val->Cantidad - BuscarNum($val->Observacion));
             }
            
           }else{
            if(Vencido($val->Vence) ===false && $val->Vence != "0000-00-00"){
              $val2->Cantidad  = $val->Cantidad + $val2->Cantidad;
            }else{
              if($val->Vence === "0000-00-00"){
                $val2->Cantidad  = $val->Cantidad + $val2->Cantidad;
              }
            }
           
           }
           }
          
         
          if($this->BuscarDentro($ListaProd,$val2->Nombre) === true){
            array_push($Arreglo2,$val2 );
          }
          
          $AuxPo = true; 
         }
       
        }
        if( $AuxPo === false){
          if($this->BuscarDentro($ListaProd,$val->Nombre) === true){
            array_push($Arreglo2,$val );
          }
          
        }
        
       
      }
   
       
  }

 

 
 
   $Predeterminado = new stdClass();
 $Predeterminado->Status2="";
 $Predeterminado->Fecha="";

  $BodyProduc =  $this->BodyTabla($Arreglo2, $ArrayProduc); 

  $Year = date("Y");
 $PT = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^PT|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');

 if(count($PT)>0){
  $PT = $PT[0];
 }else{
  $PT = $Predeterminado;
 }

 $IG = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^IG|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');

 $IG = count($IG) > 0 ? $IG[0] : $Predeterminado ;

 $CP = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^CP|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');
 $CP = count($CP) > 0 ? $CP[0] : $Predeterminado ;
 $PAN = $this->ProofModels->getProofFiltroLimiteOrdenColumnas('sTipo^PAN|Balsa^'.$Orden[0]->IDBALSA,1,0,0,"1",'s0|2|13');
 $PAN = count($PAN) > 0 ? $PAN[0] : $Predeterminado ;
 $Valvula = $this->ValveModels->getValveFiltro('sBalsa^'.$Orden[0]->CodigoBalsa);
 $Valvula = $Valvula[0];

 $Acta = $this->RaftModels->getRaft($Orden[0]->IDBALSA);
 $aux =json_encode($Valvula);
 $aux  = str_replace('FabricaciÃ³n','fabricacion',$aux);
 $Valvula =  json_decode($aux); 

 $Acta= $Acta[0];



  
// coder for CodeIgniter TCPDF Integration
// make new advance pdf document
$tcpdf = new Pdf('P', 'mm', 'A4', true, 'UTF-8', false);
 
// set document information

$tcpdf->SetAuthor('segmarind');
$tcpdf->SetTitle('Certificado De Balsas');
$tcpdf->SetSubject('segmarind');
$tcpdf->SetKeywords('TCPDF, PDF, segmarind, test, guide');
 
//set default header information
 
$tcpdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, "", "", array(0,65,256), array(0,65,127));


$tcpdf->setFooterData(array(0,65,0), array(0,65,127));
 
//set header  textual styles
$tcpdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
//set footer textual styles
$tcpdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
 
//set default monospaced textual style
$tcpdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
 
// set default margins
$tcpdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
// Set Header Margin
$tcpdf->SetHeaderMargin(PDF_MARGIN_HEADER);
// Set Footer Margin
$tcpdf->SetFooterMargin(PDF_MARGIN_FOOTER);
 
// set auto for page breaks
$tcpdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image for scale factor
$tcpdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// it is optional :: set some language-dependent strings
if (@file_exists(dirname(__FILE__).'/lang/eng.php'))
{
// optional
require_once(dirname(__FILE__).'/lang/eng.php');
// optional
$tcpdf->setLanguageArray($l);
}
 
// set default font for subsetting mode
$tcpdf->setFontSubsetting(true);



// Set textual style
// dejavusans is an UTF-8 Unicode textual style, on the off chance that you just need to
// print standard ASCII roasts, you can utilize center text styles like
// helvetica or times to lessen record estimate.
//$tcpdf->SetFont('dejavusans', '', 14, '', true);
 
// Add a new page
// This technique has a few choices, check the source code documentation for more data.
$tcpdf->AddPage();
if($FirmanteInterno != "Nada"){
  $tcpdf->Image( $Dir.'/Firmas/'.$FirmanteInterno.".png", 130, 205, 60);
}
if($FirmanteMaritima != "Nada"){
  $tcpdf->Image( $Dir.'/Firmas/'.$FirmanteMaritima.".png", 20, 235, 60);
}


$style = array(
  'border' => 0,
  'vpadding' => 'auto',
  'hpadding' => 'auto',
  'fgcolor' => array(0,0,0),
  'bgcolor' => array(255,255,255),
  'module_width' => 1, // width of a single module in points
  'module_height' => 1 // height of a single module in points
);
$MI_HOST = $this->ConfigModels->Value('MI_HOST');
 $tcpdf->write2DBarcode($MI_HOST.'CodeIgniter/CertificadoBalsa/'.$Nombre.'', 'QRCODE,Q', 90, 235, 30, 30, $style, 'C');
// set text shadow for effect
/*
$tcpdf->setTextShadow(array('enabled'=>true, 'depth_w'=>0.2, 'depth_h'=>0.2, 'color'=>array(196,197,198), 'opacity'=>1, 'blend_mode'=>'Normal'));
 
//Set some substance to print
 */
$set_html = <<<EOD
 
 
<h3  style="text-align: center; text-decoration: underline;">CERTIFICADO DE MANTENIMIENTO DE BALSAS SALVAVIDAS</h3>
<h4  style="text-align: center;">SMI $CodigoPlanilla/$Year</h4>
<div>
<FONT SIZE="9"  style="text-align: justify;"><b>    El abajo firmante, inspector debidamente autorizado por la Autoridad Marítima Chilena, certifica por la presente que ha inspeccionado la balsa salvavidas individualizada de acuerdo a las regulaciones internacionales, en cumplimiento con el capítulo III de la “Convención Internacional por la Vida Humana en el Mar, SOLAS” y declara que su estado es satisfactorio y se encuentra conforme para ser usada en caso de emergencia.</b></FONT>
</div>
<br/>
<span><FONT SIZE="9"><b>1.-          IDENTIFICACIÓN BALSA</b></FONT></span>
<br>

<table   border="1" >

<tr>
<th ><FONT SIZE="8"><b> Embarcación</b></FONT></th>
<th ><FONT SIZE="8"> $Embarcacion</FONT></th>
<th ><FONT SIZE="8"><b> PACK </b></FONT></th>
<th ><FONT SIZE="8"> $Minuteses->Pack </FONT></th>
</tr>
  <tr >
  <td ><FONT SIZE="8"><b>ARMADOR</b></FONT></td>
  <td ><FONT SIZE="8"> $Armador</FONT></td> 
  <td ><FONT SIZE="8"><b> CAPACIDAD</b></FONT></td>
  <td ><FONT SIZE="8"> $Capacidad </FONT></td>
  </tr>

  <tr>
  <td ><FONT SIZE="8"><b>N° DE SERIE</b></FONT></td>
  <td ><FONT SIZE="8"> $Serial  </FONT></td>
  <td ><FONT SIZE="8"><b> CERTIFICADO ANTERIOR</b></FONT></td>
  <td ><FONT SIZE="8"> $CerAnt</FONT></td>
  </tr>
  <tr>
  <td ><FONT SIZE="8"><b>MARCA/MODELO</b></FONT></td>
  <td ><FONT SIZE="8"> $Marca</FONT></td>
  <td ><FONT SIZE="8"><b> FECHA DE INSPECCIÓN</b></FONT></td>
  <td ><FONT SIZE="8">  $FechaI</FONT></td>
  </tr>
  <tr>
  <td ><FONT SIZE="8"><b>FECHA DE FABRICACIÓN</b></FONT></td>
  <td ><FONT SIZE="8"> $Fecha </FONT></td>
  <td ><FONT SIZE="8"><b> FECHA DE VENCIMIENTO</b></FONT></td>
  <td ><FONT SIZE="8"> $FechaV </FONT></td>
  </tr>

</table>
<br/>
<span><FONT SIZE="9"><b>2.-          CILINDRO(S) DE INFLADO(S)</b></FONT></span>
<br>

<table   border="1" >

<tr>
<th ><FONT SIZE="8"><b> SERIE</b></FONT></th>
<th ><FONT SIZE="8"><b> TARA (Kg)</b></FONT></th>
<th ><FONT SIZE="8"><b> CO2 (Kg) </b></FONT></th>
<th ><FONT SIZE="8"><b> N2 (Kg)</b></FONT></th>
<th ><FONT SIZE="8"><b> PESO TOTAL (Kg)</b></FONT></th>
<th ><FONT SIZE="8"><b> ULTIMO PH</b></FONT></th>
</tr>
$BodyCilindros

</table>
<br/>
<span><FONT SIZE="9"><b>3.-          PRUEBAS DE INFLADO</b></FONT></span>
<br>

<table   border="1" >

<tr>
<th ><FONT SIZE="8"><b> PRUEBA</b></FONT></th>
<th ><FONT SIZE="8"><b> ESTADO</b></FONT></th>
<th ><FONT SIZE="8"><b> ÙLTIMA PRUEBA</b></FONT></th>
<th ><FONT SIZE="8"><b> PRÓXIMA PRUEBA</b></FONT></th>
</tr>
  <tr >
  <td ><FONT SIZE="8"><b> PT</b></FONT></td> 
  <td ><FONT SIZE="8"> $PT->Status2</FONT></td> 
  <td ><FONT SIZE="8"> $PT->Fecha</FONT></td> 
  <td ><FONT SIZE="8"> $Acta->PT</FONT></td> 
  </tr>
  <tr >
  <td ><FONT SIZE="8"><b> IG</b></FONT></td> 
  <td ><FONT SIZE="8"> $IG->Status2</FONT></td> 
  <td ><FONT SIZE="8"> $IG->Fecha</FONT></td> 
  <td ><FONT SIZE="8"> $Acta->IG</FONT></td> 
  </tr>
  <tr >
  <td ><FONT SIZE="8"><b> CP</b></FONT></td> 
  <td ><FONT SIZE="8"> $CP->Status2</FONT></td> 
  <td ><FONT SIZE="8"> $CP->Fecha</FONT></td> 
  <td ><FONT SIZE="8"> $Acta->CP</FONT></td> 
  </tr>
  <tr >
  <td ><FONT SIZE="8"><b> PAN</b></FONT></td> 
  <td ><FONT SIZE="8"> $PAN->Status2</FONT></td> 
  <td ><FONT SIZE="8"> $PAN->Fecha</FONT></td> 
  <td ><FONT SIZE="8"> $Acta->PAN</FONT></td> 
  </tr>
</table>
<br/>
<span><FONT SIZE="9"><b>4.-          VENCIMIENTO DE EQUIPO</b></FONT></span>
<br>

<table   border="1" >

<tr>
<th ><FONT SIZE="8"><b> ELEMENTO</b></FONT></th>
<th ><FONT SIZE="8"><b> CANTIDAD</b></FONT></th>
<th ><FONT SIZE="8"><b> VENCIMIENTO</b></FONT></th>
<th ><FONT SIZE="8"><b> OBSERVACIONES</b></FONT></th>
</tr>
$BodyProduc


</table>
  Trabajos Efectuados:   $Observacion
 
EOD;

//Print content utilizing writeHTMLCell()


  $tcpdf->writeHTMLCell(0, 0, '', '', $set_html, 0, 1, 0, true, '', true);
$tcpdf->SetFont("", 'B', 10);
if ($this->AuMaritimo === true){
$tcpdf->MultiCell(70,5, "____________________________
   Inspector Autoridad Marítima
  ", 0, 'C', 0, 0, '', 242, true, 0, false, false, 35, 'M', false);
}


  $tcpdf->MultiCell(70,5, "____________________________
  Inspector Empresa
  Resolución C.P.CHB.  N° 12625/228
 ", 0, 'C', 0, 1, 125, 242, true, 0, false, false, 40, 'M', false);

 $tcpdf->SetFont("", '', 8);
 $MI_HOST = $this->ConfigModels->Value('MI_HOST');
$tcpdf->MultiCell(175,5, "Puede verificar la valides de este documiento en: ".$MI_HOST."Sistema/Certificado/Balsas Debe usar el Código: $Nombre ", 0, 'C', 0, 0, 10, 265, true, 0, false, false, 35, 'M', true);
$tcpdf->SetFont("", 'B', 10);

 $tcpdf->AddPage();
 $set_html2 = <<<EOD
 


 <br/>
 <br/>

 <h3  style="text-align: center; ">CERTIFICADO DE VÁLVULA HIDROSTÁTICA</h3>
 <br/>
 <h5  style="text-align: center;">Taller de Balsas Autorizado por Resolución G.M. AYSÉN ORD. N° 12.600/196 del 15/07/2015</h5>
 <br/>
 <br/>
 <div>
 <br/>
 <P><FONT SIZE="9"  style="text-align: center;"><b>Embarcación:</b> $Embarcacion</FONT></p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>MARCA:</b></FONT> $Valvula->Marca</p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>MODELO:</b> $Valvula->Modelo</FONT></p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>N° DE SERIE:</b> $Valvula->Serial</FONT></p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>FECHA FABRICACIÓN:</b> $Valvula->FabricaciÃ³n</FONT></p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>TIPO:</b></FONT> $Valvula->Tipo</p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>OPERA:</b></FONT> $Valvula->Opera</p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>FECHA INSPECCIÓN:</b> $FechaI </FONT></p>
 <P><FONT SIZE="9"  style="text-align: center;"><b>FECHA DE VENCIMIENTO:</b> $FechaV </FONT></p>
 </div>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/>
 <br/> 
EOD;


$tcpdf->writeHTMLCell(0, 0, '', '', $set_html2, 0, 1, 0, true, '', true); 
$set_html3 = <<<EOD
<div>
<br/>
<br/>
<br/>
<br/>
<p><FONT SIZE="9"  style="text-align: justify;"><b>El abajo firmante, inspector debidamente autorizado por la Autoridad Marítima Chilena, certifica por la presente que ha inspeccionado la Válvula Hidrostática  individualizada de acuerdo a las regulaciones internacionales, en cumplimiento con el capítulo III de la “Convención Internacional por la Vida Humana en el Mar, SOLAS” y declara que su estado es satisfactorio y se encuentra conforme para ser usada en caso de emergencia.</b></FONT></P>
</div>
EOD;

if($FirmanteInterno != "Nada"){
  $tcpdf->Image( $Dir.'/Firmas/'.$FirmanteInterno.".png", 130, 205, 60);
}
$tcpdf->writeHTMLCell(0, 0, '', '', $set_html3, 0, 1, 0, true, '', true);
$tcpdf->MultiCell(70,5, "____________________________
Inspector Autorizado
SEGMARIND SPA.
 ", 0, 'C', 0, 1, 125, 235, true, 0, false, false, 40, 'M', false);

/// cuadro 1
$tcpdf->SetLineStyle(array('width' => 1.2, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0)));
$tcpdf->RoundedRect(57, 37, 95, 9, 0, '10');


$tcpdf->SetLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0)));
$tcpdf->RoundedRect(58.5, 38.5, 92, 6, 0, '10');

// cuadro 2
$tcpdf->SetLineStyle(array('width' => 1.2, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0)));
$tcpdf->RoundedRect(41, 51, 130.1, 9, 0, '10');


$tcpdf->SetLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0)));
$tcpdf->RoundedRect(42.5, 52.5, 127, 6, 0, '10');
// cuadro grande




$tcpdf->SetLineStyle(array('width' => 1.2, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0)));
$tcpdf->RoundedRect(13, 25, 185, 160, 0, '10');


$tcpdf->SetLineStyle(array('width' => 0.5, 'cap' => 'butt', 'join' => 'miter', 'dash' => 0, 'color' => array(0, 0, 0)));
$tcpdf->RoundedRect(14.5, 26.5, 182, 157, 0, '10');
$MI_HOST = $this->ConfigModels->Value('MI_HOST');
 $tcpdf->write2DBarcode($MI_HOST.'CodeIgniter/CertificadoBalsa/'.$Nombre.'', 'QRCODE,Q', 90, 235, 30, 30, $style, 'N');
 $tcpdf->SetFont("", '', 8);
 $tcpdf->MultiCell(175,5, "Puede verificar la valides de este documiento en: ".$MI_HOST."Sistema/Certificado/Balsas Debe usar el Código: $Nombre ", 0, 'C', 0, 0, 10, 265, true, 0, false, false, 35, 'M', true);
 $tcpdf->SetFont("", 'B', 10);
// Close and yield PDF record
// This technique has a few choices, check the source code documentation for more data.

switch (count($parametros)) { 
  
  case 0:
    break;
  case 1:
    $tcpdf->Output('Certificado.pdf', 'I');
  break;
  case 2:
   if (Existe($Dir.'/certificadobalsas/') === false){
    CrearCarpeta($Dir.'/certificadobalsas/');
   
    
   }
    $this->MinutesModels->GuardarActa($parametros[0],$Nombre);
    $tcpdf->Output($Dir.'/certificadobalsas/'.$Nombre.'.pdf', 'F');
    if(($FirmanteMaritima != 'Nada' AND $FirmanteInterno != 'Nada') OR($this->AuMaritimo === false AND $FirmanteInterno != 'Nada' ) ){
      //$DatosArmador aqui enviamos los datos del certificado
      // actualizamos la fecha de vencimiento  a un ano 

    
        $DatosEditar = '{"0":"'.$Minuteses->ID.'","11":"Finalizado"}';
        $DatosEditar =  json_decode($DatosEditar, true);
        $isn= $this->MinutesModels->Edit($DatosEditar);
        $DatosEditar = '{"0":"'.$Orden[0]->Acta.'","11":"Finalizado"}';
        $DatosEditar =  json_decode($DatosEditar, true);
        $isn= $this->MinutesModels->Edit($DatosEditar);
        $DatosEditar = '{"0":"'. $CodigoDetalle.'","3":"Finalizado"}';
        $DatosEditar =  json_decode($DatosEditar, true);
        $isn= $this->DetalleOrdenModels->Edit($DatosEditar);

       

     $ordenes = $this->DetalleOrdenModels->getDetalleOrdenFiltro("sOrden^".$CodigoOrden);
      if( count($ordenes)===0){
          // significa que ya no hay balsas en la orden 
          $DatosEditar = '{"0":"'. $CodigoOrden.'","7":"Finalizado"}';
          $DatosEditar =  json_decode($DatosEditar, true);
          $isn= $this->OrderModels->Edit($DatosEditar);
        }
        // aqui vamos a modificar la balsa para agregar su certificado
        $DatosEditar = '{"0":"'. $Orden[0]->IDBALSA.'","12":"'.$Nombre.'", "13":"Activo","14":"'.$Vence.'", "15":"0"}';
        $DatosEditar =  json_decode($DatosEditar, true);
        $isn= $this->RaftModels->Edit($DatosEditar);
        $BuscamosBalsa= $this->RaftModels->getRaft($Orden[0]->IDBALSA);
        $Embarcacion = $BuscamosBalsa[0]->Embarcacion; 
        
    }
    $htmlContent = '<h1>Certificado De Balsa Salvavidas</h1>';
    $htmlContent .="<p>Balsa $Serial.</p>";
    if($Email!= ""){
      EmailHtml($Email,"SEGMARIND", $htmlContent,$Dir.'/certificadobalsas/'.$Nombre.'.pdf');
    }
    
    header("Content-type: application/pdf");
    header("Content-Disposition: inline; filename=documento.pdf");
    readfile($Dir.'certificadobalsas/'.$Nombre.'.pdf');
   
  
    return;
    
    break;
  }





//
// successfully created CodeIgniter TCPDF Integration
}
 function BuscarDentro($Array,$Palabra){

  $AuxP = mb_strtoupper($Palabra);
  $respu = false;

  for ($i=0;$i < count($Array); $i++){
   
    if( mb_strtoupper($Array[$i]) ===  $AuxP )
    $respu = true;
  }
  return $respu;
 }

function BodyTabla($arr,$Titulos){
 
  $Fi = "";
  foreach ($arr as $Fila){
    $Fi=  $Fi.'<tr>';
    $Colum= '';
 
    
         for( $i=0; $i< count($Titulos); $i++  ){
          foreach (  $Fila as $key => $val){
          if( $Titulos[$i] ===$key){
            $Colum =  $Colum. '<td ><FONT SIZE="8"> '. $val.' </FONT></td>';
          }
        }
        }
    
    $Fi= $Fi.$Colum.'</tr>';
  }
return $Fi;


}

protected function middleware()
{

  return ['Sesion','Permisos'];
}
}
/* end CertificadoBalsaCtrl.php file for CodeIgniter TCPDF Integration */
?>