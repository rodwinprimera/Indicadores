<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ChangePasswordCtrl extends MY_Controller {

  public function __construct($config = 'rest')
  {
    header('Access-Control-Allow-Origin: *');
    header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Authorization, Access-Control-Request-Method");
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
    header("Allow: GET, POST, OPTIONS, PUT, DELETE");
    header('content-type: application/json; charset=utf-8');
    $method = $_SERVER['REQUEST_METHOD'];
    if($method == "OPTIONS") {
        die();
    }
      parent::__construct();
  }
  public function _remap($met,$parametros = array()){

  $method = $_SERVER['REQUEST_METHOD'];
 if($met ==="index"){

  switch ($method)  
  { case 'PUT':
      $this->Edit(); 
    break;
    case 'GET': 
      $this->MetaData();
    break; 
   default: 
   echo json_encode( "Error" );
   break; 
  }
}


 }

     
private function Edit(){
  $Datos = $this->input->raw_input_stream;
  if(is_string($Datos) ===true){
    $Datos =  json_decode($Datos, true);
  }
  $ChangePasswordes= $this->ChangePasswordModels->Edit($Datos);
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($ChangePasswordes);
    
}


private function MetaData(){

  $ChangePasswordes =array();
  $ChangePasswordes = $this->ChangePasswordModels->MetaData();
  header('Content-type: application/json; charset=utf-8');
  echo json_encode($ChangePasswordes); 
}

    protected function middleware()
    {
        return ['Sesion'];
    }

	
}